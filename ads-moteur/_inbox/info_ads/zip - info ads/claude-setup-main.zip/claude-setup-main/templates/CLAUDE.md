# CLAUDE.md — Second Brain root

Ce fichier sert de point d'entrée pour Claude Code dans ce vault.

---

## Session init

Au démarrage de chaque conversation Claude Code dans ce dossier :

1. Lis `{{BRAIN_PATH}}/user.md` — profil de {{USER_NAME}}.
2. Lis `{{BRAIN_PATH}}/environment.md` — machine et outils dispo.
3. Lis `{{BRAIN_PATH}}/agents/{{AGENT_ID}}/soul.md` — adopte cette personnalité.
4. Charge les API keys : `source {{BRAIN_PATH}}/secrets/keystore.env`.

---

## Structure du vault

- `user.md` — profil utilisateur
- `environment.md` — environnement machine
- `goals.md` — objectifs actifs
- `agents/<id>/soul.md` — personnalités d'agents
- `skills/` — skills locaux + clones GitHub
- `secrets/` — keystore (chmod 600)
- `Projects/` — notes par projet
- `learning/` — lessons learned

---

## Règles non-négociables

1. **Jamais leak une clé** — la valeur du keystore ne doit jamais apparaître en clair dans un log, un commit ou une réponse.
2. **Toujours préserver le vault existant** — pas de `rm -rf` agressif. Préfère archive/move.
3. **Délégation pour les tâches > 10s** — l'agent ne bloque pas l'utilisateur.
4. **Mise à jour de `goals.md`** quand un nouvel objectif est exprimé.
5. **Mise à jour de `learning/`** quand une leçon non-évidente est découverte.
