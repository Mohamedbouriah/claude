---
name: ads-winners-loop
description: Écrit et audite en boucle des publicités Meta rentables pour du coaching / high-ticket, en travaillant uniquement le COPY et l'OFFRE (jamais le ciblage ni la structure de campagne). Fondé sur trois comptes réels — reconquête masculine, parentalité ado, management de PME — avec les performances chiffrées de chaque ad, les corrections appliquées et les découvertes validées. Utiliser ce skill DÈS QUE l'utilisateur veut écrire, réécrire, décliner ou auditer une ad Meta, un hook, un angle, un script face-caméra, une accroche ou un P.S. ; dès qu'il colle des perfs (CTR, CPL, hook rate, coût par lead qualifié) et demande quoi garder, couper ou décliner ; dès qu'il veut transformer un verbatim client, une donnée d'onboarding ou un transcript d'appel en angle publicitaire ; dès qu'il veut formuler ou reformuler une offre, une promesse ou un prix. Utiliser aussi quand une ad « sonne IA », quand un CTR élevé ne produit aucun lead, ou quand l'utilisateur demande pourquoi une ad ne convertit pas. Le skill BOUCLE obligatoirement : il écrit, il audite contre 9 filtres, il liste les violations, il réécrit, et il recommence jusqu'à zéro violation. Il ne livre jamais un premier jet.
---

# Ads Winners Loop — copy et offre

Ce skill produit des ads Meta rentables en ne touchant qu'au **copy** et à l'**offre**. Pas de ciblage, pas de pixel, pas de structure de campagne, pas de budget.

Tout ce qu'il contient vient de trois comptes réels, avec les chiffres en face. Ce qui n'est pas mesuré est marqué comme hypothèse.

Statuts utilisés partout : 🟢 mesuré sur au moins deux comptes · 🟡 mesuré sur un seul · 🔴 non prouvé

---

## Le principe unique

> **Une ad rentable NOMME ce que le prospect vit sans l'avoir jamais formulé. Une ad qui échoue DÉCRIT ce qu'il sait déjà.**

- DÉCRIRE → « après une rupture, on se sent perdu » → il le sait → indifférence
- NOMMER → « t'as été l'homme qu'elle voulait, t'es resté cet homme trop longtemps » → il ne l'avait jamais dit comme ça → reconnaissance → mouvement

Preuve : cette ad a divisé le CPL par deux et fait passer les verbatims de qualité de 0 % à 43 %. Elle a porté 64 % du budget du compte. 🟢

**Le verbatim est le matériau, pas la décoration.** Ne jamais inventer un verbatim, un chiffre, un taux, une ancienneté. Si le verbatim manque, aller le chercher dans les données d'onboarding, les transcripts d'appels ou les réponses de formulaire. Une revendication inventée est le seul type d'erreur qui se paie au téléphone, quand le prospect la teste.

---

## La boucle — workflow obligatoire

Le skill ne livre jamais un premier jet.

```
1. BRIEF       → cible + angle + verbatim source + état d'achat visé
2. STRUCTURE   → placer les 6 blocs canoniques
3. ÉCRITURE    → rédiger
4. AUDIT       → passer les 8 filtres, un par un, explicitement
5. DÉTECTION   → lister chaque violation, avec la ligne fautive citée
6. si ≥1 violation → RÉÉCRITURE ciblée → retour en 4
7. si 0 violation → contrôle machine (scripts/audit.py) → LIVRAISON
```

**Ne jamais sauter l'audit**, même sur une ad qui « semble bonne ». La majorité des défauts — langage de coach, verbatim inventé, promesse sur un tiers, densité trop élevée — ne se voient qu'en relisant ligne par ligne.

Le script `scripts/audit.py` fait le contrôle déterministe : vocabulaire interdit, densité syllabique, longueur des blocs, chiffres non sourcés. Il ne remplace pas l'audit humain, il attrape ce que la lecture rate.

```bash
python3 scripts/audit.py mon_ad.txt --duree 45
```

---

## Les 6 blocs canoniques

Structure validée sur les ads face-caméra de 45 à 67 secondes. Les blocs A et B changent selon l'angle ; C, D, E, F sont quasi invariants — c'est la signature du système.

| Bloc | Timing | Rôle |
|---|---|---|
| **A — Hook** | 0-3 s | NOMMER l'état intérieur. Jamais décrire la situation. |
| **B — Scène de contraste** | 3-15 s | Le quotidien concret, dans SES mots. Deux moments qui s'opposent. |
| **C — Disculpation** | 15-20 s | « C'est pas toi le problème » + la raison mécanique. Sans ce bloc, le prospect défend son noyau et ne clique pas. |
| **D — Mécanisme inversé** | 20-31 s | Pourquoi ce qu'il fait produit l'inverse de ce qu'il veut. C'est le rouage, pas le verdict. |
| **E — Incarnation** | 31-45 s | Qui parle, et un chiffre vérifiable. Jamais un chiffre rond, jamais inventé. |
| **F — CTA** | 45-67 s | Un geste tangible + le filtre + la nature de ce qu'il obtient. |

Le **P.S.** est un bloc à part, réservé aux ads en texte long : il traite l'objection n°1 par anticipation. Détail et exemples dans `references/ads-reelles.md`.

---

## Les états d'achat

Tous les états émotionnels ne s'achètent pas. Deux convertissent, un ne convertit jamais. 🟢

**TOUT ESSAYÉ** — épuisement + soulagement. « T'as tout tenté, et rien n'a marché. Normal. » Convertit.

**MENACE IDENTITAIRE** — menace + validation. « Ce que t'as construit est en train de t'échapper. » Convertit.

**NOMINATION DU PATTERN** — reconnaissance pure. « Tu fais toujours la même erreur. » **Hook rate le plus élevé du corpus — 35,9 % — et zéro lead.** Le prospect se reconnaît, hoche la tête, et passe à autre chose. La reconnaissance sans issue ne produit aucun mouvement.

Règle : **toute reconnaissance doit être suivie d'une disculpation et d'une issue.** Nommer sans absoudre produit du hook rate, pas des leads.

---

## Les filtres d'audit

Chaque filtre se passe explicitement, en citant la ligne fautive. Le détail de chacun, avec exemples avant/après, est dans `references/audit.md` — à charger avant le premier audit.

**Filtre 0 — PRÉSENCE.** À passer en premier, et c'est le plus souvent oublié : les sept autres filtres sont négatifs, ils traquent ce qu'il ne faut pas faire. Une ad peut ne rien violer et ne rien promettre. Vérifier que les six blocs existent, et surtout que **le prospect sait ce qu'il obtient**. Une ad sans livrable nommé passe tous les filtres et ne convertit pas.

1. **NOMMER, pas décrire** — le hook reformule-t-il ce qu'il se dit, ou décrit-il sa situation ?
2. **Verbatim sourcé** — chaque phrase attribuée au prospect existe-t-elle dans les données ? Chaque chiffre a-t-il une source ?
3. **Disculpation présente** — l'ad absout-elle avant de demander quoi que ce soit ?
4. **Mécanisme, pas verdict** — l'ad explique-t-elle *pourquoi* ça échoue, ou se contente-t-elle d'affirmer ?
5. **Aucune promesse sur un tiers** — l'ad promet-elle ce que fera l'autre personne (l'ex, l'équipe, l'ado) ?
6. **Zéro identité** — l'ad accuse-t-elle une nature, ou nomme-t-elle un acte ?
7. **Lexique** — un mot de la liste interdite apparaît-il ? Le niveau de langue est-il celui de la cible ?
8. **Densité** — 218 à 246 syllabes pour 45 secondes. Au-delà, la conversion se dégrade. 🟡

---

## Le lexique

**Interdits sur toute la chaîne** — ad, funnel, message, appel :
*posture · masculinité · mindset · transformation · accompagnement · développement personnel · travailler sur toi · prise de conscience · lâcher-prise · bienveillance · reprendre le pouvoir · alignement · haute valeur*

**Imposés** — le vocabulaire du livrable :
*les mots · les messages · quoi envoyer · quoi faire · quoi arrêter · les armes · je suis derrière toi · deux jours · étape par étape*

**Règles de registre :**
- Toujours « les hommes », jamais « les mecs »
- Français niveau lecture 12 ans
- Aucun emoji dans les ads coaching adulte
- Le vocabulaire ne doit jamais réduire l'envergure de la cible : à un dirigeant on ne dit pas « ton petit business »

Le lexique interdit **court sur tous les étages**. Un mot banni dans l'ad reste banni dans le funnel, dans le message et au téléphone. C'est ce qui empêche la dette d'objection.

---

## L'offre — ce qui se vend et ce qui se livre

> **On vend les armes. On livre la transformation.**

Le seul appel closé du corpus est resté sur le livrable : « je vais te montrer quoi lui envoyer, je suis derrière toi sur chaque message ». Quatre appels perdus sur sept ont basculé sur l'identité (« ta posture », « redeviens un homme »). 🟢

Et le client formule sa transformation **lui-même, après avoir acheté** : les questionnaires en cours d'accompagnement parlent de « meilleure version de moi-même » et de « renaître ». Il n'a pas acheté ça. Il l'a trouvé dedans.

Corollaire mesuré : **le marché arrive déjà en auto-attribution.** 36 % seulement blâment le contexte chez les managers, 20 des 45 payants nomment spontanément leur excès. Dépenser l'ad à faire prendre conscience, c'est travailler un terrain déjà acquis.

Doctrine complète — aveu tolérable, prix, promesse, filtre financier — dans `references/offre.md`.

---

## Lire les performances

**Le taux de clic ne prédit rien.** 🟢

| Cas | CTR | Ce qui s'est passé derrière |
|---|---|---|
| AD 5 « La flamme éteinte » | **14,1 %** — 7× la moyenne | 1 seconde de session médiane, 83 % de rebond, **zéro clic sur la page** |
| AD 4 « Le film du soir » | 7,3 % | 41,7 % restent plus de 30 s **et** cliquent — la seule qui tient les deux bouts 🟡 |
| Hook « nomination du pattern » | hook rate 35,9 % | **zéro lead** |

**Métriques de créa, dans l'ordre :** coût par lead qualifié > durée de session > profondeur de lecture > taux d'opt-in. Le clic arrive dernier.

**Signature à connaître :** si trois créas différentes produisent le même taux de rebond à un point près (41,2 % / 41,1 % / 43,8 % sur un compte réel), le problème n'est pas la créa — c'est la page. Ne pas chercher une meilleure accroche. 🟡

Procédure complète de décision garder/couper/décliner dans `references/audit.md`.

---

## Où chercher la matière

Avant d'écrire, ouvrir dans cet ordre :

1. **Les données d'onboarding des clients payants** — leurs mots exacts sur ce qu'ils ont fait, ce qu'ils craignent, pourquoi ils ont acheté maintenant
2. **Les transcripts d'appels** — les objections réelles, et surtout la phrase de celui qui a signé
3. **Les réponses de formulaire** — la fréquence des excès, des freins, des états déclarés
4. **Les commentaires et messages entrants** — la langue non filtrée

Une ad écrite sans cette matière produit du DÉCRIRE. C'est mécanique.

---

## Les fichiers de référence

| Fichier | Quand le lire |
|---|---|
| `references/ads-reelles.md` | Avant d'écrire — 12 ads réelles annotées avec leurs performances, sur 3 comptes |
| `references/corrections.md` | Avant de réécrire — chaque correction appliquée, avec l'avant/après et la raison |
| `references/audit.md` | Avant le premier audit — les 8 filtres en détail, et la procédure garder/couper |
| `references/offre.md` | Quand l'offre, la promesse ou le prix sont en jeu |
| `scripts/audit.py` | À chaque itération, avant de livrer |
