# Les corrections — avant / après

Chaque correction vient d'une itération réelle. C'est la mémoire des erreurs à ne pas refaire.

---

## C1 — Le verdict sans le mécanisme

**Avant :** « Les vidéos YouTube te disent silence radio. Tes potes te disent passe à autre chose. Tous sincères. **Tous à côté.** »

**Défaut :** « tous à côté » est une assertion d'autorité. Elle demande au prospect de croire sur parole — exactement ce que font les conseils qu'on prétend disqualifier.

**Après :** « Quand on te sort *passe à autre chose*, toi t'entends : *elle t'a déjà remplacé*. Ça fait plus mal que la rupture. Et le silence radio ? On te dit quoi arrêter. Jamais quoi **faire**. Alors t'attends — et l'angoisse mouline. »

**Règle :** une assertion juge, un mécanisme déloge. Ne jamais contredire une croyance : l'expliquer dans son échec, pour qu'elle puisse être lâchée sans que le prospect ait eu tort de l'avoir crue.

---

## C2 — La promesse sur un tiers

**Avant :** « C'est tout frais. **Elle est encore attachée à toi**, même si elle le montre pas. »

**Défaut :** promesse invérifiable sur l'état d'une autre personne. Crée la dette « vous m'aviez dit que » — qui explose au closing.

**Après :** « C'est tout frais. Et là, t'as sûrement qu'une envie : lui écrire pour tout arranger. C'est le réflexe qui fait le plus de dégâts. »

**Règle :** ne jamais promettre ce que fera ou ressentira l'autre — l'ex, l'équipe, l'ado. On promet un cadre, un savoir, un geste. Jamais une réaction.

---

## C3 — Le ton d'expert au lieu du monologue

**Avant :** « Un mois, c'est trop court pour que ses sentiments aient disparu. Mais c'est aussi la période où **les hommes** font le plus de dégâts. »

**Défaut :** raisonne depuis la position de l'observateur, et parle des hommes en général.

**Après :** « Et là, t'as sûrement qu'une envie : lui écrire pour tout arranger. »

**Règle :** le test — chaque phrase doit pouvoir se préfixer par « tu es en train de te dire que… ». Si ça grince, c'est de la description.

---

## C4 — Le lexique qui se réintroduit par la petite porte

**Avant :** « Pendant ce temps, **tu ne travailles pas sur** ce qui compte. »

**Après :** « Pendant ce temps, t'avances sur rien. »

**Règle :** scanner le fichier entier à chaque itération. Le lexique interdit revient toujours par les phrases de liaison, jamais par les phrases principales.

---

## C5 — L'excès mal calibré sur la donnée

**Avant :** trois options d'aveu — trop disponible / **trop donné** / pas assez là.

**Découverte :** dans les données réelles, « trop donné » ne pèse que 2 cas sur 45, alors que **la jalousie et le contrôle en pèsent 9**. Un cluster de 20 % passait entre les mailles.

**Après :** trop disponible / **trop jaloux, je voulais tout contrôler** / trop pris ailleurs. Avec la réaction qui disculpe : « la jalousie, c'est de la peur de la perdre mal exprimée — elle a reçu du contrôle là où toi t'avais de l'attachement ».

**Règle :** calibrer les options sur la fréquence réelle, pas sur l'intuition. Et toujours reformuler le défaut en peur ou en excès.

---

## C6 — Le mot administratif qui tue la valeur

**Avant :** « Voilà le **formulaire** dont je te parlais. »
**Après :** « Voilà le **diagnostic** dont je te parlais. »

Et dans le CTA : « remplis le formulaire » → « fais le diagnostic ».

**Règle :** aucun mot administratif dans une promesse. Le mot du CTA doit être le même que celui de la page qui suit.

---

## C7 — La précision temporelle qui sonne fabriqué

**Avant :** « Mardi 6h45, le vendeur revient de sa pause à 14h. »

**Défaut :** signature de texte généré. Les vrais professionnels parlent par périodes.

**Après :** « le matin », « ces derniers temps », « en ce moment ».

---

## C8 — Le calcul en cascade

**Avant :** « Combien de places × ta marge × douze mois… »

**Défaut :** casse le rythme, fait décrocher.

**Après :** la douleur brute nommée en verbatim. Le calcul, s'il existe, se fait **dans la restitution**, pas dans l'ad.

---

## C9 — Le vocabulaire qui réduit l'envergure

**Avant :** « un truc que t'as monté »
**Après :** « une affaire », « ce que t'as bâti », « ton équipe »

**Règle :** le vocabulaire réducteur tue la reconnaissance chez un dirigeant.

---

## C10 — La preuve sociale au mauvais étage

**Avant, sur l'écran de confirmation après le oui :** « 76 % ont vu leur ex refaire le premier pas. »

**Défaut :** juxtaposée à l'action, la statistique fabrique un lien causal faux — « je prends le créneau donc 76 % de chances ». Et sur-vendre après le oui est le réflexe du vendeur qui insiste.

**Après :** la certitude procédurale — « ce qui se passe sur ce call : on reprend ton diagnostic, je te montre le plan, et si c'est jouable je te dis comment je t'accompagne. Tu décides à la fin, pas avant. »

**Règle :** chaque preuve a son étage. Les statistiques travaillent quand le prospect doute encore. Après le oui, elles deviennent du bruit.

---

## C11 — Le chiffre inventé

**Avant :** « Je dirige une PME depuis **20 ans**. »

**Défaut :** aucune source ne l'atteste. C'était une invention.

**Après :** « 227 managers accompagnés. Et je fais surtout une chose : je sors les équipes du bureau. » — les deux vérifiables dans ses propres supports.

**Règle :** aucune ancienneté, aucun taux, aucune rareté sans source. C'est la seule erreur qui se paie au téléphone.

---

## C12 — La promesse générique au lieu de la promesse de l'ad

**Avant, sur la page d'arrivée :** « 4 minutes, je te dis ce qui bloque dans ton équipe. »

**Défaut :** c'est la promesse du diagnostic, pas celle de l'ad. Le prospect vient de lire une promesse de transformation, il atterrit sur une promesse de formulaire.

**Après :** « Deux jours. Et ton équipe arrête de dépendre de toi. » — la promesse de l'ad, en grand, avec l'accroche cliquée rappelée au-dessus.

**Règle :** la page d'arrivée récompense le clic avant de demander quoi que ce soit. Ce qu'il gagne d'abord, qui le lui donne ensuite.
