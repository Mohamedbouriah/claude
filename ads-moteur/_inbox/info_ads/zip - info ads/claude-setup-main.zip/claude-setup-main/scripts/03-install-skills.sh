#!/usr/bin/env bash
# 03-install-skills.sh — Clone les skills et sub-agents
# - anthropics/skills → ~/brainOS/skills/anthropic/
# - msitarzewski/agency-agents → ~/brainOS/skills/github/agency-agents + copie *.md vers ~/.claude/agents/

set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/lib/colors.sh"
source "$SCRIPT_DIR/lib/log.sh"
source "$SCRIPT_DIR/lib/ask.sh"

[ -f /tmp/claude-setup-env.sh ] && source /tmp/claude-setup-env.sh
BRAIN_PATH="${CS_BRAIN_PATH:-$HOME/brainOS}"

log_step "03" "Installation des skills et sub-agents"

if ! command -v git >/dev/null 2>&1; then
  log_err "git absent — étape skippée"
  exit 0
fi

mkdir -p "$BRAIN_PATH/skills/anthropic" "$BRAIN_PATH/skills/github" "$HOME/.claude/agents"

# 1) anthropics/skills — skills officiels
TARGET_ANTHROPIC="$BRAIN_PATH/skills/anthropic"
if [ -d "$TARGET_ANTHROPIC/.git" ]; then
  log_skip "anthropics/skills déjà cloné — pull"
  git -C "$TARGET_ANTHROPIC" pull --quiet 2>/dev/null || log_warn "git pull a échoué (offline ?)"
else
  log_info "Clone anthropics/skills…"
  if git clone --depth 1 https://github.com/anthropics/skills.git "$TARGET_ANTHROPIC" 2>/dev/null; then
    log_ok "anthropics/skills cloné"
  else
    log_warn "Clone échoué (réseau ?) — réessaie plus tard"
  fi
fi

# 2) msitarzewski/agency-agents — sub-agents
TARGET_AGENCY="$BRAIN_PATH/skills/github/agency-agents"

if ask_yes_no "Installer les 32 sub-agents Agency dans ~/.claude/agents/ ?" "y"; then
  if [ -d "$TARGET_AGENCY/.git" ]; then
    log_skip "agency-agents déjà cloné — pull"
    git -C "$TARGET_AGENCY" pull --quiet 2>/dev/null || log_warn "git pull a échoué"
  else
    log_info "Clone msitarzewski/agency-agents…"
    if git clone --depth 1 https://github.com/msitarzewski/agency-agents.git "$TARGET_AGENCY" 2>/dev/null; then
      log_ok "agency-agents cloné"
    else
      log_warn "Clone échoué — réessaie plus tard"
    fi
  fi

  # Copie tous les *.md trouvés dans le repo vers ~/.claude/agents/
  if [ -d "$TARGET_AGENCY" ]; then
    COUNT=0
    while IFS= read -r -d '' file; do
      base="$(basename "$file")"
      # Skip README, LICENSE, et docs racine
      case "$base" in
        README*|LICENSE*|CONTRIBUTING*|CHANGELOG*|CODE_OF_CONDUCT*) continue ;;
      esac
      cp "$file" "$HOME/.claude/agents/$base"
      COUNT=$((COUNT + 1))
    done < <(find "$TARGET_AGENCY" -type f -name "*.md" ! -path "*/.git/*" -print0)
    log_ok "$COUNT sub-agents copiés vers ~/.claude/agents/"
  fi
else
  log_skip "Agency sub-agents skippés"
fi

log_done "Skills et sub-agents installés"
