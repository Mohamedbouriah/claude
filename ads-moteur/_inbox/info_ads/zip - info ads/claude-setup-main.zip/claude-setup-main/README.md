<div align="center">

<img src="https://img.shields.io/badge/AGENTIC-SETUP-12A594?style=flat-square&labelColor=12A594&color=1A1A1A" alt="AGENTIC · SETUP">

# Autonomous Dev Setup

### D'une installation vide à un environnement Claude Code productif, en 5 minutes.

```
   _____ _                 _        _____      _
  / ____| |               | |      / ____|    | |
 | |    | | __ _ _   _  __| | ___ | (___   ___| |_ _   _ _ __
 | |    | |/ _` | | | |/ _` |/ _ \ \___ \ / _ \ __| | | | '_ \
 | |____| | (_| | |_| | (_| |  __/ ____) |  __/ |_| |_| | |_) |
  \_____|_|\__,_|\__,_|\__,_|\___||_____/ \___|\__|\__,_| .__/
                                                        | |
                                                        |_|
```

Tout ce qu'un nouveau dev doit configurer après l'install,<br>fait à sa place par une seule conversation.<br>Tu pars de zéro, tu repars équipé.

<br>

<a href="https://bizos.cc">
<img src="https://img.shields.io/badge/BizOS-build%20autonomous%20companies-0A0A0A?style=for-the-badge&labelColor=0A0A0A" alt="BizOS — build autonomous companies">
</a>

<br><br>

<a href="https://x.com/gauthierthiry"><img src="https://img.shields.io/badge/@gauthierthiry-0A0A0A?style=flat-square&logo=x&logoColor=white" alt="X"></a>
<a href="https://youtube.com/@gquthier"><img src="https://img.shields.io/badge/@gquthier-FF0000?style=flat-square&logo=youtube&logoColor=white" alt="YouTube"></a>

<br>

<sub>Skill conversationnel · Second Brain · CLIs · serveurs MCP · skills · sub-agents · clés API</sub>

</div>

---

`claude-setup` est un skill conversationnel qui automatise tout ce qu'un nouveau dev doit faire après avoir installé Claude Code : Second Brain, CLIs, MCP servers, skills, sub-agents et API keys. Une seule commande, et tu pars de zéro à un environnement productif.

## Quick start

```bash
bash <(curl -fsSL https://raw.githubusercontent.com/gquthier/claude-setup/main/install.sh)
```

Le script va :

1. Détecter ton OS, shell et runtimes installés.
2. Initialiser ton Second Brain à `~/brainOS/`.
3. Installer les CLIs manquants (Claude Code, gh, vercel, playwright).
4. Cloner [`anthropics/skills`](https://github.com/anthropics/skills) et [`msitarzewski/agency-agents`](https://github.com/msitarzewski/agency-agents).
5. Câbler le Playwright MCP server dans `~/.claude.json`.
6. Centraliser tes API keys dans `~/brainOS/secrets/keystore.env` (chmod 600).
7. Créer un agent perso avec son `soul.md`.

Le tout en posant ~12 questions et en respectant ce qui est déjà installé.

---

## What's included

| Composant | Source | Destination |
|-----------|--------|-------------|
| Second Brain (Obsidian-compatible) | Templates locaux | `~/brainOS/` |
| Skills officiels Anthropic | [`anthropics/skills`](https://github.com/anthropics/skills) | `~/brainOS/skills/anthropic/` |
| 32 sub-agents Agency | [`msitarzewski/agency-agents`](https://github.com/msitarzewski/agency-agents) | `~/.claude/agents/` |
| Playwright MCP server | `@playwright/mcp` (npx) | `~/.claude.json` |
| Claude Code CLI | `@anthropic-ai/claude-code` | `/usr/local/bin/claude` |
| GitHub CLI | Homebrew / apt | `/usr/local/bin/gh` |
| Vercel CLI | npm | `~/.npm-global/bin/vercel` |
| API keys keystore | env vars + prompts | `~/brainOS/secrets/keystore.env` (chmod 600) |
| Agent perso | Template `soul.md` | `~/brainOS/agents/<id>/soul.md` |

---

## Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                     Claude Code Session                      │
│                                                              │
│   ┌────────────┐   ┌────────────┐   ┌──────────────────┐   │
│   │   Skills   │   │ Sub-agents │   │   MCP Servers    │   │
│   │  ~/.claude │   │ ~/.claude/ │   │  ~/.claude.json  │   │
│   │  /skills   │   │   agents   │   │  (playwright,…)  │   │
│   └────────────┘   └────────────┘   └──────────────────┘   │
│         │                │                    │              │
│         └────────────────┴────────────────────┘              │
│                          │                                   │
│                          ▼                                   │
│            ┌────────────────────────────┐                   │
│            │       Second Brain         │                   │
│            │       ~/brainOS/           │                   │
│            │  user.md   environment.md  │                   │
│            │  goals.md  agents/<id>/    │                   │
│            │  skills/   secrets/        │                   │
│            └────────────────────────────┘                   │
└─────────────────────────────────────────────────────────────┘
```

Voir [`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md) pour le détail.

---

## Personalization

Le skill pose ~12 questions pour personnaliser ton setup :

- **Identité** — prénom, rôle, stack principal.
- **Niveau Claude Code** — pour adapter le ton et la verbosité de l'agent perso.
- **Agent perso** — nom et ton (formel / direct / cool), génère un `soul.md`.
- **Intégrations** — Vercel, GitHub, Anthropic API.
- **Path Second Brain** — `~/brainOS` par défaut, customisable.

Toutes les réponses sont stockées dans `~/brainOS/user.md` et peuvent être éditées plus tard.

---

## Troubleshooting

Voir [`docs/TROUBLESHOOTING.md`](docs/TROUBLESHOOTING.md) pour les problèmes courants :

- `gh` non authentifié → relance `gh auth login`.
- Playwright MCP ne se charge pas → vérifie que `npx` est dans le PATH.
- Permission denied sur `keystore.env` → `chmod 600 ~/brainOS/secrets/keystore.env`.
- Le keystore ne se lit pas dans Claude Code → ajoute `source ~/brainOS/secrets/keystore.env` dans ton shell rc.

---

## Idempotent by design

Relance `install.sh` autant de fois que tu veux. Le script :

- Skip les CLIs déjà installés.
- Préserve les fichiers existants (sauf demande explicite).
- Merge la config MCP via `jq` — n'écrase rien.
- Conserve les API keys déjà présentes.

---

## Inspiré de

- Présentation YouTube de [@gquthier](https://github.com/gquthier) — *Le setup parfait pour Claude Code*.
- [`anthropics/skills`](https://github.com/anthropics/skills) — skills officiels.
- [`msitarzewski/agency-agents`](https://github.com/msitarzewski/agency-agents) — collection communautaire de sub-agents.

---

## License

MIT — voir [`LICENSE`](LICENSE).

Built by [Gauthier](https://github.com/gquthier).

---

<div align="center">

<br>

### Tu construis quelque chose qui tourne tout seul ?

**[bizos.cc](https://bizos.cc)** — build autonomous companies.

<br>

<a href="https://x.com/gauthierthiry"><img src="https://img.shields.io/badge/@gauthierthiry-0A0A0A?style=flat-square&logo=x&logoColor=white" alt="X"></a>
<a href="https://youtube.com/@gquthier"><img src="https://img.shields.io/badge/@gquthier-FF0000?style=flat-square&logo=youtube&logoColor=white" alt="YouTube"></a>

<br><br>

<sub>Par <a href="https://x.com/gauthierthiry">Gauthier Thiry</a></sub>

</div>
