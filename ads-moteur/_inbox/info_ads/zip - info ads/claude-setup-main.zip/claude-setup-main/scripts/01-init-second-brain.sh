#!/usr/bin/env bash
# 01-init-second-brain.sh — Crée la structure ~/brainOS/ avec les fichiers de base
# Demande prénom, rôle, stack, niveau, path

set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/lib/colors.sh"
source "$SCRIPT_DIR/lib/log.sh"
source "$SCRIPT_DIR/lib/ask.sh"

# Charger detect si dispo
[ -f /tmp/claude-setup-env.sh ] && source /tmp/claude-setup-env.sh

log_step "01" "Initialisation du Second Brain"

# Q5 — Path
DEFAULT_BRAIN="$HOME/brainOS"
BRAIN_PATH="$(ask "Path du Second Brain" "$DEFAULT_BRAIN")"
BRAIN_PATH="${BRAIN_PATH/#\~/$HOME}"

if [ -d "$BRAIN_PATH" ] && [ -f "$BRAIN_PATH/user.md" ]; then
  log_skip "Second Brain existe déjà à $BRAIN_PATH — préservé."
  echo "export CS_BRAIN_PATH=\"$BRAIN_PATH\"" >> /tmp/claude-setup-env.sh
  exit 0
fi

# Création de la structure
mkdir -p "$BRAIN_PATH"/{agents,skills,Projects,learning,secrets,subagent,Large\ Memory,dashboard,rules}
chmod 700 "$BRAIN_PATH/secrets"

log_ok "Dossiers racine créés"

# Q1-4 — Profile
USER_NAME="$(ask "Ton prénom" "Dev")"
USER_ROLE="$(ask_choice "Ton rôle" "dev|designer|pm|founder" "dev")"
USER_STACK="$(ask_choice "Stack principal" "ts|python|go|other" "ts")"
USER_LEVEL="$(ask_choice "Niveau Claude Code" "débutant|intermédiaire|avancé" "intermédiaire")"

# Templates
TEMPLATES_DIR="$SCRIPT_DIR/../templates"

# user.md (filled from answers)
sed -e "s|{{NAME}}|$USER_NAME|g" \
    -e "s|{{ROLE}}|$USER_ROLE|g" \
    -e "s|{{STACK}}|$USER_STACK|g" \
    -e "s|{{LEVEL}}|$USER_LEVEL|g" \
    "$TEMPLATES_DIR/user.md" > "$BRAIN_PATH/user.md"
log_ok "user.md créé"

# environment.md (auto-detected)
OS_VAL="${CS_OS:-$(uname -s)}"
ARCH_VAL="${CS_ARCH:-$(uname -m)}"
SHELL_VAL="${CS_SHELL:-$SHELL}"
NODE_VAL="$(command -v node 2>/dev/null && node --version 2>/dev/null || echo 'non installé')"
PYTHON_VAL="$(command -v python3 2>/dev/null && python3 --version 2>/dev/null || echo 'non installé')"

sed -e "s|{{OS}}|$OS_VAL|g" \
    -e "s|{{ARCH}}|$ARCH_VAL|g" \
    -e "s|{{SHELL}}|$SHELL_VAL|g" \
    -e "s|{{NODE}}|$NODE_VAL|g" \
    -e "s|{{PYTHON}}|$PYTHON_VAL|g" \
    -e "s|{{BRAIN_PATH}}|$BRAIN_PATH|g" \
    "$TEMPLATES_DIR/environment.md" > "$BRAIN_PATH/environment.md"
log_ok "environment.md créé"

# goals.md (empty template)
cp "$TEMPLATES_DIR/goals.md" "$BRAIN_PATH/goals.md"
log_ok "goals.md créé (vide, à remplir)"

# Export pour les scripts suivants
{
  echo "export CS_BRAIN_PATH=\"$BRAIN_PATH\""
  echo "export CS_USER_NAME=\"$USER_NAME\""
  echo "export CS_USER_ROLE=\"$USER_ROLE\""
  echo "export CS_USER_STACK=\"$USER_STACK\""
  echo "export CS_USER_LEVEL=\"$USER_LEVEL\""
} >> /tmp/claude-setup-env.sh

log_done "Second Brain initialisé à $BRAIN_PATH"
