# Environment

Auto-detected by `claude-setup` at install time.

## Machine

- **OS**: {{OS}} ({{ARCH}})
- **Shell**: {{SHELL}}
- **Node**: {{NODE}}
- **Python**: {{PYTHON}}
- **Second Brain path**: `{{BRAIN_PATH}}`

## Vault structure

| Path | What it is |
|------|------------|
| `user.md` | Your profile (read at session start) |
| `environment.md` | This file — machine info + paths |
| `goals.md` | Daily/weekly goals |
| `agents/<id>/soul.md` | Personality of each agent |
| `skills/` | Local skills + cloned `anthropics/skills` and `agency-agents` |
| `secrets/keystore.env` | Centralized API keys (chmod 600) |
| `Projects/` | Per-project notes |
| `learning/` | Lessons from past sessions |

## Loading API keys

Keys are stored in `{{BRAIN_PATH}}/secrets/keystore.env`. Source it manually or add to your shell rc:

```bash
[ -f {{BRAIN_PATH}}/secrets/keystore.env ] && source {{BRAIN_PATH}}/secrets/keystore.env
```

## MCP servers

Configured in `~/.claude.json`. By default after `claude-setup`:

- `playwright` — browser automation via `@playwright/mcp@latest`

## CLIs available

Run `which <cmd>` to check : `claude`, `gh`, `vercel`, `node`, `python3`, `playwright`, `jq`.

> Re-run `claude-setup` to refresh detection.
