# User Profile

I am **{{NAME}}**, a {{ROLE}} working primarily with {{STACK}}.

## Claude Code level

{{LEVEL}}

## Working style

- Direct communication. Concise updates.
- Prefer running tools rather than describing actions.
- Always check the Second Brain before assuming context.

## Stack

- **Primary language**: {{STACK}}
- **Tooling**: Claude Code, Git, GitHub CLI
- **Cloud**: TBD — fill once a deployment target is chosen.

## Preferences

- Add your specific preferences here.
- Naming conventions, formatting, dependency policies, etc.

> Edit this file freely. Agents will use it to personalize their behavior.
