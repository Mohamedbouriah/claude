#!/usr/bin/env bash
# 04-setup-mcp.sh — Configure les MCP servers dans ~/.claude.json (merge via jq, ne pas écraser)

set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/lib/colors.sh"
source "$SCRIPT_DIR/lib/log.sh"
source "$SCRIPT_DIR/lib/ask.sh"

[ -f /tmp/claude-setup-env.sh ] && source /tmp/claude-setup-env.sh

log_step "04" "Configuration des MCP servers"

CONFIG="$HOME/.claude.json"

if ! command -v jq >/dev/null 2>&1; then
  log_err "jq absent — impossible de merger la config en sécurité. Skip."
  exit 0
fi

# Demande
if ! ask_yes_no "Installer le Playwright MCP server ?" "y"; then
  log_skip "Playwright MCP skippé"
  exit 0
fi

# Crée le fichier si absent
if [ ! -f "$CONFIG" ]; then
  echo '{}' > "$CONFIG"
  log_info "Fichier ~/.claude.json créé"
fi

# Backup
cp "$CONFIG" "$CONFIG.bak.$(date +%s)"
log_info "Backup créé"

# Merge via jq — préserve la config existante
TMP="$(mktemp)"
jq '.mcpServers = (.mcpServers // {}) | .mcpServers.playwright = {
  "command": "npx",
  "args": ["-y", "@playwright/mcp@latest"]
}' "$CONFIG" > "$TMP" && mv "$TMP" "$CONFIG"

log_ok "Playwright MCP ajouté à ~/.claude.json"

# Vérification
if jq -e '.mcpServers.playwright' "$CONFIG" >/dev/null 2>&1; then
  log_ok "Config validée"
else
  log_err "Config invalide après merge — restore depuis backup"
fi

log_done "MCP servers configurés"
