# Les ads réelles — 3 comptes, performances et annotations

Sommaire
1. D'Angelo — reconquête masculine, 1 497 €
2. Sabine — parentalité ado
3. Yohann — management de PME, format texte long
4. Ce qui traverse les trois

---

# 1. D'ANGELO — reconquête masculine

Format : face-caméra 45 à 67 secondes. CPL de référence 5,98 €.

## AD 2B — LA WINNER · 64 % du budget, fréquence 2,17

**Hook :** « T'as été l'homme qu'elle voulait. T'es resté cet homme trop longtemps. »

**Performance :** CPL divisé par deux contre la variante 2A. Verbatims de qualité dans les leads : **0 % → 43 %**. 🟢

**Pourquoi ça marche, bloc par bloc :**

- *Hook* — NOMME l'état. Ne dit pas « tu as fait des erreurs » (description) mais retourne sa qualité en excès. Il ne s'était jamais formulé ça.
- *Disculpation intégrée au hook* — « t'as été l'homme qu'elle voulait » valide avant de nommer le défaut. C'est ce qui autorise l'aveu sans détruire le noyau.
- *L'excès comme cadre* — « trop longtemps » est un excès de durée, pas un manque de valeur. **C'est la formulation la plus importante du corpus** : l'aveu tolérable est toujours l'excès d'une qualité, jamais l'absence d'une qualité.

**La variante perdante 2A** décrivait la situation (« elle est partie et tu ne comprends pas pourquoi »). Même offre, même cible, même format : CPL doublé.

## AD 5F — « Silence radio » · meilleur coût par lead qualifié : 31 €

Prend la croyance dominante du marché (le silence radio) et la **complète au lieu de la contredire**. Le prospect peut lâcher sa croyance sans avoir eu tort de l'avoir crue.

Formulation validée : *« On te dit quoi arrêter. Jamais quoi faire. Alors t'attends — et c'est dans l'attente que l'angoisse mouline. »*

## AD « NOMINATION DU PATTERN » — hook rate 35,9 %, ZÉRO lead

L'ad qui a le mieux capté l'attention de tout le compte n'a produit aucun lead. Elle nommait le pattern sans donner d'issue ni absoudre. **Reconnaissance ≠ mouvement.**

À retenir : un hook rate élevé isolé n'est pas un signal positif. Il faut le croiser avec le coût par lead qualifié avant toute décision.

## LE HOOK TALLY QUI A CASSÉ LE COMPTE

**Formulation :** « Tu veux récupérer ton ex et tu sais que tu dois changer ta posture ? »

**Résultat :** 70 % des répondants cherchaient des solutions gratuites. 474 sur un formulaire déclarent « pas d'argent ». 🟢

**Deux fautes cumulées :**
1. **Présupposition** — « tu sais que tu dois » présuppose l'aveu. Ça sélectionne les hommes très conscients du marché… qui sont précisément ceux qui ont déjà tout consommé gratuitement.
2. **Lexique** — « posture » est un mot de coach. Il attire des consommateurs de contenu de coaching, pas des acheteurs.

## LA MATIÈRE DISPONIBLE (45 clients payants)

| Donnée | Valeur | Usage en copy |
|---|---|---|
| Excès « trop disponible / trop présent » | 19/45 | angle n°1 |
| Excès « jalousie, contrôle » | 9/45 | angle n°2, à formuler en peur, pas en défaut |
| Excès « pas assez là, trop pris » | 8/45 | angle n°3 |
| Problème n°1 déclaré | **l'angoisse** (17/45) | le bénéfice à promettre, avant la technique |
| Séparés depuis moins de 3 mois | 81 % | fenêtre à nommer dans le hook |
| N'avaient jamais payé de coaching | 88 % | ne jamais présupposer la maturité marché |
| Veulent être dirigés | 40/45 | le CTA peut être directif |
| Achètent en moins de 7 jours | 70 % | l'urgence est réelle, pas fabriquée |

---

# 2. SABINE — parentalité ado

CPC 0,30 € · CPM 8,81 € · CPL réel 8,25 €.

| Ad | Format | Budget | CPL | Lecture |
|---|---|---|---|---|
| AD 1 « Sentinelle » | studio | **429 € — 57 % du budget** | **13,42 €** | le pire coût des créas qui délivrent, et pourtant la plus financée |
| AD V2 « Sentinelle selfie » | UGC | 22 € | **7,39 €** | meilleur CPL du compte 🟡 |
| AD V3 « Prisonnière selfie » | UGC | 38 € | **7,67 €** | 🟡 |
| AD V8 « la main qui écrit » | UGC | 217 € | 10,86 € | bon CPL, mais Meta la classe dans les 35 % les moins bien notées en conversion — clic pas cher qui convertit mal |

**L'archétype Sentinelle** — la mère qui contrôle tout — est l'équivalent exact du 2B de D'Angelo : le contrôle est un **excès de peur**, pas un défaut de caractère. Même mécanique, autre niche.

**Le noyau** : « je suis une mauvaise mère ». **La protection** : l'intellectualisation — « je cherche à comprendre » (52 répondantes sur 105). L'ad ne doit jamais nourrir l'intellectualisation : expliquer davantage renforce la protection.

**Direction 🟡 :** l'UGC selfie bat le studio d'un facteur deux sur le CPL. Budgets trop déséquilibrés pour conclure — à tester à budget égal sur sept jours.

---

# 3. YOHANN — management de PME, texte long

CPL 11,89 €. Format : texte long avec histoire à la troisième personne + P.S.

| Ad | CTR | Dépense | Ce que dit le post-clic |
|---|---|---|---|
| AD 5 « La flamme éteinte » | **14,14 %** | 46 € | **1 s de session, 83 % de rebond, 0 clic — le piège** |
| AD 4 « Le film du soir » | 7,34 % | 49 € | 41,7 % > 30 s, 41,7 % cliquent — **la seule à tenir les deux bouts** 🟡 |
| AD 2 « Le classeur de plus » | 2,15 % | 42 € | rebond 36,4 % |
| AD 3 « L'ancien collègue » | 1,99 % | **564 €** | rebond 41,2 % |
| AD 6 « Le pilote automatique » | 1,91 % | 411 € | rebond 41,1 % |
| AD 1 « Le poker face » | 1,65 % | 161 € | rebond 43,8 % |

**Le rebond identique sur les trois grosses créas (41,2 / 41,1 / 43,8) prouve que le décrochage vient de la page, pas de l'accroche.** Aucune créa ne sauvera cette page. 🟡

## La structure texte long validée

Sur ce compte, les ads longues suivent un schéma stable :

1. **Un tiers nommé, avec sa phrase** — « David dirige depuis 20 ans. Et chaque matin, il refait le boulot que son équipe était censée faire. *C'est surtout moi que ça tend*, il dit. »
2. **La scène répétée** — la tâche qui traîne, il la reprend, il redemande, rien ne bouge
3. **La croyance fausse nommée** — « je suis pas assez carré », qu'il se dit
4. **Le renversement mécanique** — « à chaque fois qu'il comble, il apprend à son équipe qu'elle n'a pas besoin de le faire »
5. **La boucle explicitée** — plus il fait, moins ils apprennent ; moins ils apprennent, plus il fait
6. **Le vrai diagnostic** — « c'est pas une équipe qui s'engage pas, c'est un cadre qui ne tient pas »
7. **Le pivot fondateur** — qui parle, et pourquoi lui
8. **Le CTA** — action simple, registre pair à pair
9. **Le P.S.** — l'objection n°1 traitée d'avance

**Le P.S. le mieux construit du corpus :**
> « Si tu te dis "j'ai pas le temps cette année", c'est exactement pour ça qu'il faut le faire. Tant que ton équipe apprend pas à tourner sans toi, t'auras jamais le temps. C'est deux jours pour en récupérer des centaines. »

Il retourne l'objection en argument, et il chiffre. C'est le modèle à répliquer.

## Les patterns mesurés (25 diagnostics)

| Pattern | Fréquence | Exploitation |
|---|---|---|
| Rumination « j'aurais dû dire ça » | **84 %** | déjà utilisé — l'accroche du compte |
| Se justifier, chercher l'approbation | **72 %** | **angle vierge, le plus gros gisement inexploité** |
| Sait que rien ne changera seul | 64 % | argument d'urgence |
| Laisse passer quand on le coupe | 60 % | scène concrète |
| Enrobe tant que le message ne passe pas | 56 % | mécanisme |
| Blâme le contexte | 36 % | minoritaire — ne pas construire dessus |
| **Syndrome de l'imposteur** | **32 % — dernier** | **ne jamais vendre là-dessus** |

**La croyance centrale**, donnée par le coach lui-même : *« Si je recadre, on ne m'aimera plus. »* Elle explique toute la chaîne comportementale. Elle reste **implicite dans l'ad** — on nomme l'acte, jamais la peur, sinon le dirigeant se braque exactement comme les hommes se braquent sur la posture.

---

# 4. CE QUI TRAVERSE LES TROIS COMPTES

**L'aveu tolérable est toujours l'excès d'une qualité.** « T'es resté cet homme trop longtemps » · « ta peur de la perdre a pris le contrôle » · « tu refais à leur place parce que c'est plus rapide ». Jamais un manque, jamais une nature.

**Le hook gagnant est une scène intérieure jamais dite à voix haute.** « Plus j'en fais, plus elle s'éloigne » · « je rumine le soir en me disant j'aurais dû dire ça ». Testable : la phrase doit pouvoir se préfixer par « tu es en train de te dire que… » sans grincer.

**L'identité est le plus faible des angles, partout.** Imposteur dernier des neuf patterns à 32 % ; quatre appels perdus sur sept sur une accusation de posture.

**Le taux de clic ment dans les trois comptes.** Toujours croiser avec le comportement post-clic avant de décider.

**Le marché arrive déjà lucide.** Ce qui manque au prospect n'est pas la compréhension, c'est le geste.
