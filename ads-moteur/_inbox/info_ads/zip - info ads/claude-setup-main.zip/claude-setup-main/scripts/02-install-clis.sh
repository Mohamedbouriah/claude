#!/usr/bin/env bash
# 02-install-clis.sh — Installe les CLIs essentiels (claude, gh, vercel, jq, playwright)
# Idempotent : skip ce qui est déjà là

set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/lib/colors.sh"
source "$SCRIPT_DIR/lib/log.sh"
source "$SCRIPT_DIR/lib/ask.sh"

[ -f /tmp/claude-setup-env.sh ] && source /tmp/claude-setup-env.sh

log_step "02" "Installation des CLIs essentiels"

OS="${CS_OS:-$(uname -s)}"

# Helper: install via brew on Mac/Linuxbrew, fallback otherwise
install_brew_pkg() {
  local pkg="$1"
  if command -v brew >/dev/null 2>&1; then
    brew install "$pkg" >/dev/null 2>&1 && log_ok "$pkg installé (brew)" || log_warn "$pkg : brew install a échoué"
  else
    log_warn "$pkg : brew absent, installation manuelle requise"
  fi
}

install_npm_global() {
  local pkg="$1"
  local bin="$2"
  if ! command -v npm >/dev/null 2>&1; then
    log_warn "$pkg : npm absent, installation skippée"
    return 0
  fi
  npm install -g "$pkg" >/dev/null 2>&1 && log_ok "$bin installé (npm -g $pkg)" || log_warn "$bin : npm install a échoué"
}

# jq — requis pour la suite (merge config MCP)
if ! command -v jq >/dev/null 2>&1; then
  log_info "Installation de jq…"
  install_brew_pkg jq
else
  log_skip "jq déjà installé"
fi

# Claude Code CLI
if ! command -v claude >/dev/null 2>&1; then
  log_info "Installation de Claude Code CLI…"
  if command -v npm >/dev/null 2>&1; then
    install_npm_global "@anthropic-ai/claude-code" "claude"
  else
    log_warn "Claude Code : npm absent — install manuelle https://docs.claude.com/claude-code"
  fi
else
  log_skip "claude déjà installé ($(claude --version 2>/dev/null | head -1 || echo 'version inconnue'))"
fi

# GitHub CLI
if ! command -v gh >/dev/null 2>&1; then
  log_info "Installation de GitHub CLI…"
  install_brew_pkg gh
else
  log_skip "gh déjà installé"
fi

# Vercel CLI
if ! command -v vercel >/dev/null 2>&1; then
  if ask_yes_no "Installer Vercel CLI ?" "y"; then
    install_npm_global "vercel" "vercel"
  else
    log_skip "vercel skippé par l'utilisateur"
  fi
else
  log_skip "vercel déjà installé"
fi

# Playwright (browser automation, requis pour le MCP server)
if ! command -v playwright >/dev/null 2>&1; then
  if ask_yes_no "Installer Playwright (browsers) ?" "y"; then
    install_npm_global "playwright" "playwright"
    if command -v playwright >/dev/null 2>&1; then
      log_info "Téléchargement des navigateurs Playwright…"
      playwright install chromium >/dev/null 2>&1 && log_ok "Chromium installé" || log_warn "Playwright install : échec partiel"
    fi
  else
    log_skip "playwright skippé"
  fi
else
  log_skip "playwright déjà installé"
fi

# GitHub auth check
if command -v gh >/dev/null 2>&1; then
  if gh auth status >/dev/null 2>&1; then
    log_ok "gh authentifié"
  else
    log_warn "gh non authentifié — lance 'gh auth login' plus tard"
  fi
fi

log_done "CLIs vérifiés/installés"
