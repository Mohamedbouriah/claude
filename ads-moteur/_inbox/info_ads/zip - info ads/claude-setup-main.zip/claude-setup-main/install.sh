#!/usr/bin/env bash
# install.sh — Claude Setup orchestrator
# Usage: bash <(curl -fsSL https://raw.githubusercontent.com/gquthier/claude-setup/main/install.sh)
#   or:  bash install.sh   (after git clone)

set -euo pipefail

# Resolve script dir even when run via curl | bash
if [ -n "${BASH_SOURCE[0]:-}" ] && [ -f "${BASH_SOURCE[0]}" ]; then
  SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
else
  # Run via curl | bash → clone temporairement
  SCRIPT_DIR="$(mktemp -d)"
  echo "==> Téléchargement de claude-setup dans $SCRIPT_DIR…"
  if ! command -v git >/dev/null 2>&1; then
    echo "ERR: git requis pour le mode curl|bash" >&2
    exit 1
  fi
  git clone --depth 1 https://github.com/gquthier/claude-setup.git "$SCRIPT_DIR" >/dev/null 2>&1 || {
    echo "ERR: clone échoué" >&2
    exit 1
  }
fi

source "$SCRIPT_DIR/scripts/lib/colors.sh"
source "$SCRIPT_DIR/scripts/lib/log.sh"
source "$SCRIPT_DIR/scripts/lib/ask.sh"

# Trap for clean errors
trap 'log_err "Échec à la ligne $LINENO. Voir les logs ci-dessus."' ERR

# Banner
clear
cat <<'EOF'

   _____ _                 _        _____      _
  / ____| |               | |      / ____|    | |
 | |    | | __ _ _   _  __| | ___ | (___   ___| |_ _   _ _ __
 | |    | |/ _` | | | |/ _` |/ _ \ \___ \ / _ \ __| | | | '_ \
 | |____| | (_| | |_| | (_| |  __/ ____) |  __/ |_| |_| | |_) |
  \_____|_|\__,_|\__,_|\__,_|\___||_____/ \___|\__|\__,_| .__/
                                                        | |
                                                        |_|

EOF

printf "${C_BCYAN}Le setup parfait pour Claude Code en 5 minutes${C_RESET}\n"
printf "${C_DIM}v1.0.0  ·  github.com/gquthier/claude-setup${C_RESET}\n\n"

if ! ask_yes_no "On y va ?" "y"; then
  echo "Bye."
  exit 0
fi

# Run scripts in order
bash "$SCRIPT_DIR/scripts/00-detect-system.sh"
bash "$SCRIPT_DIR/scripts/01-init-second-brain.sh"
bash "$SCRIPT_DIR/scripts/02-install-clis.sh"
bash "$SCRIPT_DIR/scripts/03-install-skills.sh"
bash "$SCRIPT_DIR/scripts/04-setup-mcp.sh"
bash "$SCRIPT_DIR/scripts/05-collect-keys.sh"
bash "$SCRIPT_DIR/scripts/06-create-agent.sh"

# Charge l'env final
[ -f /tmp/claude-setup-env.sh ] && source /tmp/claude-setup-env.sh

# Recap
log_section "CLAUDE SETUP — TERMINÉ"

BRAIN_PATH="${CS_BRAIN_PATH:-$HOME/brainOS}"
AGENT_ID="${CS_AGENT_ID:-bro}"

# Compte les sub-agents
AGENT_COUNT=0
if [ -d "$HOME/.claude/agents" ]; then
  AGENT_COUNT="$(find "$HOME/.claude/agents" -maxdepth 1 -type f -name "*.md" | wc -l | tr -d ' ')"
fi

# Compte les keys
KEY_COUNT=0
if [ -f "$BRAIN_PATH/secrets/keystore.env" ]; then
  KEY_COUNT="$(grep -cE '^[A-Z_]+=' "$BRAIN_PATH/secrets/keystore.env" 2>/dev/null || echo 0)"
fi

cat <<EOF

  Second Brain        : $BRAIN_PATH/
  Agent perso         : $BRAIN_PATH/agents/$AGENT_ID/soul.md
  Sub-agents installés: $AGENT_COUNT (~/.claude/agents/)
  API keys            : $KEY_COUNT stockées dans ~/brainOS/secrets/keystore.env
  MCP servers actifs  : playwright

  Next steps :
    1. Lance Claude Code        : claude
    2. Charge le contexte       : skill session-bootstrap
    3. Vérifie ton agent perso  : cat $BRAIN_PATH/agents/$AGENT_ID/soul.md
    4. Source les keys au shell : echo "[ -f \$HOME/brainOS/secrets/keystore.env ] && source \$HOME/brainOS/secrets/keystore.env" >> ~/.zshrc

  Bon dev.

EOF
