---
name: claude-setup
description: Bootstrap complet d'un environnement Claude Code optimisé. Installe les CLIs, configure les MCP servers, clone les skills et sub-agents, centralise les API keys et initialise un Second Brain personnel. À lancer une seule fois après l'installation de Claude Code.
---

# Claude Setup — Le setup parfait pour Claude Code

Ce skill automatise le bootstrap complet d'un nouvel utilisateur Claude Code. En 5 minutes, tu passes d'une installation vierge à un environnement productif avec Second Brain, sub-agents, skills et MCP servers.

> Inspiré de la présentation YouTube de Gauthier — "Le setup parfait pour Claude Code".

---

## Objectif

Mettre en place en une seule commande :

1. Un **Second Brain** (`~/brainOS/`) qui sert de mémoire persistante à tous tes agents.
2. Les **CLIs essentiels** (Claude Code, GitHub CLI, Vercel CLI, Playwright).
3. Les **skills officiels Anthropic** (`anthropics/skills`) et la collection communautaire.
4. Les **32 sub-agents Agency** (`msitarzewski/agency-agents`) installés dans `~/.claude/agents/`.
5. Le **Playwright MCP server** câblé dans la config Claude Code.
6. Une **gestion centralisée des API keys** (`~/brainOS/secrets/keystore.env`, chmod 600).
7. Un **agent perso** avec son `soul.md`, créé à partir de tes réponses.

---

## Quand l'utiliser

- Juste après avoir installé Claude Code pour la première fois.
- Quand tu reçois une nouvelle machine et tu veux retrouver ton setup en 5 min.
- Pour mettre à jour un setup existant — le script est **idempotent**, il skip ce qui existe déjà.

---

## Procédure (8 étapes orchestrées)

```
00 — detect-system     → OS, shell, runtimes, package managers
01 — init-second-brain → ~/brainOS/{user.md, environment.md, goals.md, ...}
02 — install-clis      → claude, gh, vercel, playwright (si absents)
03 — install-skills    → anthropics/skills + agency-agents → ~/.claude/agents/
04 — setup-mcp         → Playwright MCP dans ~/.claude.json (jq merge)
05 — collect-keys      → Toutes les API keys → ~/brainOS/secrets/keystore.env
06 — create-agent      → Agent perso avec soul/identity à partir des réponses
07 — recap             → Résumé final + next steps
```

Chaque script est **lancable individuellement** depuis `scripts/` si tu veux skip ou rejouer une étape.

---

## Questions posées à l'utilisateur

Le skill est conversationnel. Il pose ~12 questions, distribuées sur les scripts :

| # | Question | Script |
|---|----------|--------|
| 1 | Ton prénom ? | 01 |
| 2 | Ton rôle (dev / designer / PM / founder) ? | 01 |
| 3 | Stack principal (TS / Python / Go / Other) ? | 01 |
| 4 | Niveau Claude Code (débutant / intermédiaire / avancé) ? | 01 |
| 5 | Path du Second Brain (défaut `~/brainOS`) ? | 01 |
| 6 | Tu veux un agent perso ? Si oui, son nom ? | 06 |
| 7 | Ton de l'agent (formel / direct / cool) ? | 06 |
| 8 | Tu vas utiliser Vercel ? | 05 |
| 9 | Tu utilises GitHub ? | 02 + 05 |
| 10 | Tu as un compte Anthropic API ? | 05 |
| 11 | Tu veux Playwright MCP installé maintenant ? (oui par défaut) | 04 |
| 12 | Tu veux les 32 sub-agents Agency ? (oui par défaut) | 03 |

Si une réponse est déjà connue (env var, config existante), elle est récupérée silencieusement.

---

## Output final

Une fois les 8 étapes terminées, l'utilisateur voit :

```
======================================================================
  CLAUDE SETUP — TERMINÉ
======================================================================

Second Brain        : ~/brainOS/
Agent perso         : ~/brainOS/agents/<id>/soul.md
Sub-agents installés: 32 (~/.claude/agents/)
API keys            : 5 stockées dans ~/brainOS/secrets/keystore.env
MCP servers actifs  : playwright

Next steps :
  1. Lance Claude Code : `claude`
  2. Charge le contexte avec le skill `session-bootstrap`
  3. Vérifie ton agent perso : `cat ~/brainOS/agents/<id>/soul.md`

Bon dev.
```

---

## Lancement

### Mode one-liner (recommandé pour un nouveau dev)

```bash
bash <(curl -fsSL https://raw.githubusercontent.com/gquthier/claude-setup/main/install.sh)
```

### Mode local (pour développer/tester le skill)

```bash
git clone https://github.com/gquthier/claude-setup.git
cd claude-setup
bash install.sh
```

### Mode étape par étape

```bash
bash scripts/00-detect-system.sh
bash scripts/01-init-second-brain.sh
# ... etc
```

---

## Idempotence

Tous les scripts sont rejouables. Si tu relances `install.sh` :

- Les CLIs déjà installés sont skippés (`command -v` check).
- Les fichiers existants ne sont jamais écrasés sans confirmation.
- Les API keys déjà présentes dans le keystore ne sont pas redemandées.
- La config MCP est mergée via `jq`, pas écrasée.

---

## Architecture finale

Voir [`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md) pour le schéma complet : comment le Second Brain, les skills, les agents et les MCP servers s'articulent dans le workflow Claude Code.
