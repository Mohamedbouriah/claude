# Architecture — Claude Setup

Ce document décrit comment les pièces s'articulent après un `install.sh` réussi.

---

## Les 4 piliers

```
┌──────────────────────────────────────────────────────────────┐
│                     Claude Code Session                       │
│                                                               │
│   ┌────────────┐  ┌────────────┐  ┌─────────────────────┐   │
│   │   Skills   │  │ Sub-agents │  │     MCP Servers     │   │
│   │  GitHub +  │  │  Agency +  │  │   Playwright (+++)  │   │
│   │  locaux    │  │   custom   │  │                     │   │
│   └─────┬──────┘  └─────┬──────┘  └──────────┬──────────┘   │
│         │               │                     │              │
│         └───────────────┴─────────────────────┘              │
│                         │                                     │
│                         ▼                                     │
│           ┌──────────────────────────┐                        │
│           │      Second Brain        │                        │
│           │      ~/brainOS/          │                        │
│           │  user · env · goals      │                        │
│           │  agents · skills · keys  │                        │
│           └──────────────────────────┘                        │
└──────────────────────────────────────────────────────────────┘
```

| Pilier | Localisation | Rôle |
|--------|--------------|------|
| **Skills** | `~/brainOS/skills/anthropic/`, `~/brainOS/skills/github/` | Procédures réutilisables. L'agent lit `INDEX.md` puis charge le `SKILL.md` adéquat. |
| **Sub-agents** | `~/.claude/agents/*.md` | Profils que Claude Code peut spawn pour déléguer. 32 inclus par défaut (Agency). |
| **MCP servers** | `~/.claude.json` → `mcpServers` | Outils exposés à l'agent (Playwright pour le browser, etc.). |
| **Second Brain** | `~/brainOS/` | Mémoire persistante : profil, environnement, goals, agent souls, secrets, projets. |

---

## Flow d'une session typique

1. **Bootstrap** — l'agent lit `~/brainOS/user.md` + `environment.md` + `agents/<id>/soul.md`.
2. **Détection de la tâche** — l'agent regarde `~/brainOS/skills/INDEX.md` pour voir s'il existe une procédure.
3. **Délégation si nécessaire** — l'agent peut spawn un sous-agent depuis `~/.claude/agents/` si la tâche est lourde.
4. **Exécution** — l'agent utilise les MCP tools (Playwright pour le browser, etc.) et les CLIs (gh, vercel).
5. **Mémoire** — l'agent écrit ses learnings dans `~/brainOS/learning/` ou met à jour `goals.md`.

---

## Pourquoi ce setup

Le setup vise à résoudre 4 problèmes récurrents :

1. **L'agent oublie le contexte d'une session à l'autre** → Second Brain persistant.
2. **L'agent ne sait pas quels outils sont dispo** → `environment.md` rempli automatiquement.
3. **L'agent réinvente la roue à chaque tâche** → skills officiels Anthropic + custom.
4. **L'agent bloque sur les tâches lourdes** → sub-agents Agency délégables.

---

## Idempotence garantie

Chaque script peut être rejoué :

| Script | Condition de skip |
|--------|-------------------|
| `00-detect-system` | Toujours rejouable (overwrite `/tmp/claude-setup-env.sh`) |
| `01-init-second-brain` | Skip si `$BRAIN_PATH/user.md` existe déjà |
| `02-install-clis` | Skip par CLI si `command -v <cli>` retourne un path |
| `03-install-skills` | `git pull` au lieu de `git clone` si `.git` existe |
| `04-setup-mcp` | `jq` merge — n'écrase jamais la config existante |
| `05-collect-keys` | Skip une key si déjà dans le keystore |
| `06-create-agent` | Skip si `agents/<id>/soul.md` existe |

---

## Évolution du skill

Pour ajouter un nouveau MCP server, edit `04-setup-mcp.sh`. Pour ajouter une CLI, edit `02-install-clis.sh`. Pour ajouter une question, distribue-la dans le script où elle a du sens (et exporte la valeur dans `/tmp/claude-setup-env.sh` pour les scripts suivants).
