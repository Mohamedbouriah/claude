#!/usr/bin/env bash
# log.sh — clean logging helpers (no emoji, ANSI colors)
# Source after colors.sh

log_step() {
  # Numbered step header — bold cyan
  printf "\n${C_BCYAN}==> [%s] %s${C_RESET}\n" "$1" "$2"
}

log_info() {
  printf "${C_DIM}    %s${C_RESET}\n" "$1"
}

log_ok() {
  printf "${C_GREEN}    OK   ${C_RESET}%s\n" "$1"
}

log_skip() {
  printf "${C_YELLOW}    SKIP ${C_RESET}%s\n" "$1"
}

log_warn() {
  printf "${C_BYELLOW}    WARN ${C_RESET}%s\n" "$1"
}

log_err() {
  printf "${C_BRED}    ERR  ${C_RESET}%s\n" "$1" >&2
}

log_section() {
  # Big section banner
  local title="$1"
  printf "\n${C_BMAGENTA}======================================================================\n"
  printf "  %s\n" "$title"
  printf "======================================================================${C_RESET}\n"
}

log_done() {
  printf "${C_BGREEN}    DONE ${C_RESET}%s\n" "$1"
}
