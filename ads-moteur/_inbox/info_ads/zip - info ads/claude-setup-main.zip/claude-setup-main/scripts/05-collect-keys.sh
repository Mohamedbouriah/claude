#!/usr/bin/env bash
# 05-collect-keys.sh — Collecte les API keys et les stocke dans ~/brainOS/secrets/keystore.env (chmod 600)
# - Si l'env var existe déjà → on la récupère
# - Sinon → on demande (silencieux), on valide grossièrement le format

set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/lib/colors.sh"
source "$SCRIPT_DIR/lib/log.sh"
source "$SCRIPT_DIR/lib/ask.sh"

[ -f /tmp/claude-setup-env.sh ] && source /tmp/claude-setup-env.sh
BRAIN_PATH="${CS_BRAIN_PATH:-$HOME/brainOS}"

log_step "05" "Collecte des API keys"

KEYSTORE="$BRAIN_PATH/secrets/keystore.env"
mkdir -p "$BRAIN_PATH/secrets"
touch "$KEYSTORE"
chmod 600 "$KEYSTORE"

# Helper: charge la valeur existante du keystore
get_existing() {
  local name="$1"
  grep -E "^${name}=" "$KEYSTORE" 2>/dev/null | head -1 | cut -d= -f2- | tr -d '"' || true
}

# Helper: ajoute ou remplace une clé dans le keystore
upsert_key() {
  local name="$1"
  local value="$2"
  if [ -z "$value" ]; then
    return 0
  fi
  # Strip existing line
  if grep -qE "^${name}=" "$KEYSTORE" 2>/dev/null; then
    grep -vE "^${name}=" "$KEYSTORE" > "$KEYSTORE.tmp" && mv "$KEYSTORE.tmp" "$KEYSTORE"
  fi
  # Ajoute (escape les " dans la valeur)
  local escaped
  escaped=$(printf '%s' "$value" | sed 's/"/\\"/g')
  printf '%s="%s"\n' "$name" "$escaped" >> "$KEYSTORE"
  chmod 600 "$KEYSTORE"
}

# Helper: prompt + validation
collect_key() {
  local name="$1"
  local hint="$2"
  local prefix_check="${3:-}"  # ex: sk-, ghp_

  # 1. Existe en env ?
  local from_env="${!name:-}"
  if [ -n "$from_env" ]; then
    upsert_key "$name" "$from_env"
    log_ok "$name (depuis env var)"
    return 0
  fi

  # 2. Déjà dans le keystore ?
  local existing
  existing="$(get_existing "$name")"
  if [ -n "$existing" ]; then
    log_skip "$name (déjà dans keystore)"
    return 0
  fi

  # 3. Demande
  if ask_yes_no "Configurer $name ($hint) ?" "n"; then
    local value
    value="$(ask_secret "Valeur de $name")"
    if [ -z "$value" ]; then
      log_skip "$name (vide)"
      return 0
    fi
    # Validation grossière
    if [ -n "$prefix_check" ] && [[ "$value" != ${prefix_check}* ]]; then
      log_warn "$name ne commence pas par '$prefix_check' — stocké quand même"
    fi
    upsert_key "$name" "$value"
    log_ok "$name stocké"
  else
    log_skip "$name skippé"
  fi
}

collect_key ANTHROPIC_API_KEY  "Claude API"      "sk-ant-"
collect_key OPENAI_API_KEY     "OpenAI API"      "sk-"
collect_key VERCEL_TOKEN       "Vercel deploy"   ""
collect_key GITHUB_TOKEN       "GitHub PAT"      "ghp_"
collect_key SUPABASE_URL       "Supabase URL"    "https"
collect_key SUPABASE_ANON_KEY  "Supabase anon"   ""

log_info "Keystore: $KEYSTORE (chmod 600)"
log_info "Pour charger les clés : source $KEYSTORE"

log_done "API keys centralisées"
