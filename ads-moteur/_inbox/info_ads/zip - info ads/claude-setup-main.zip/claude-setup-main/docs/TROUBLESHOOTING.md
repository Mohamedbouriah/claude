# Troubleshooting

Problèmes courants et solutions.

---

## Installation

### `bash: jq: command not found` au step 04

`jq` est requis pour merger la config MCP en sécurité. Le script `02-install-clis.sh` essaie de l'installer via Homebrew. Si Homebrew est absent :

```bash
# macOS
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
brew install jq

# Linux (Debian/Ubuntu)
sudo apt-get install -y jq

# Linux (Arch)
sudo pacman -S jq
```

Puis relance `bash install.sh`.

---

### `gh: command not found` ou `gh auth status` échoue

```bash
# Install
brew install gh   # macOS
# ou
sudo apt-get install gh   # Ubuntu

# Auth
gh auth login
```

Le skill ne bloque pas si `gh` n'est pas auth, mais certaines features (création de repo, clone privé) échoueront.

---

### Le clone d'`anthropics/skills` ou `agency-agents` échoue

Causes habituelles :
- Pas de connexion réseau → relance plus tard.
- Pas d'auth GitHub → `gh auth login` ou `git config --global credential.helper`.
- Rate limit anonyme → utilise un PAT : `git config --global url."https://YOUR_PAT@github.com/".insteadOf "https://github.com/"`.

---

## Runtime

### Claude Code ne charge pas le MCP Playwright

Vérifie que la config est valide :

```bash
jq '.mcpServers.playwright' ~/.claude.json
```

Doit retourner :

```json
{
  "command": "npx",
  "args": ["-y", "@playwright/mcp@latest"]
}
```

Si invalide : restore depuis le backup généré par le script (`~/.claude.json.bak.<timestamp>`).

---

### Le keystore ne se charge pas dans Claude Code

Le fichier `~/brainOS/secrets/keystore.env` n'est pas chargé automatiquement. Ajoute à ton `~/.zshrc` ou `~/.bashrc` :

```bash
[ -f $HOME/brainOS/secrets/keystore.env ] && source $HOME/brainOS/secrets/keystore.env
```

Puis `source ~/.zshrc`.

---

### Permission denied sur `keystore.env`

```bash
chmod 600 ~/brainOS/secrets/keystore.env
```

Le mode 600 est obligatoire — le script le force, mais si tu l'as touché manuellement, vérifie.

---

## Agent perso

### L'agent ignore son `soul.md`

Vérifie que :

1. Ton CLAUDE.md racine du projet (ou de ton vault) référence bien le path.
2. La session Claude Code a bien démarré dans un dossier où le `CLAUDE.md` est visible (`~/brainOS/CLAUDE.md`).
3. Tu as bien lancé le skill `session-bootstrap` au début de session.

---

### Je veux changer le ton de mon agent

Edit directement `~/brainOS/agents/<id>/soul.md`. La section `## Communication` contient le ton.

---

## Reset complet

Pour repartir de zéro (attention : supprime le Second Brain) :

```bash
rm -rf ~/brainOS
rm -f ~/.claude.json
rm -rf ~/.claude/agents
bash <(curl -fsSL https://raw.githubusercontent.com/gquthier/claude-setup/main/install.sh)
```

> Backup d'abord : `cp -r ~/brainOS ~/brainOS.backup.$(date +%s)`.
