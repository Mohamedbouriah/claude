# Les 9 filtres d'audit

## Filtre 0 — PRÉSENCE (à passer en premier)

**Découvert en testant ce skill sur une ad neuve :** les huit filtres suivants sont tous négatifs. Une ad peut les passer tous — zéro violation, densité parfaite — et ne rien promettre au prospect. C'est le défaut le plus difficile à voir, parce que rien ne le signale.

Vérifier la présence de chaque élément :

| Élément | Question | Si absent |
|---|---|---|
| Hook | nomme-t-il un état intérieur ? | l'ad n'accroche pas |
| Scène | y a-t-il un moment concret, situé ? | l'ad reste abstraite |
| Disculpation | l'ad absout-elle ? | le prospect défend son noyau |
| Mécanisme | l'ad explique-t-elle le rouage ? | l'ad affirme sans convaincre |
| Chiffre vérifiable | y a-t-il une incarnation chiffrée ? | aucune preuve |
| **Livrable** | **le prospect sait-il ce qu'il obtient ?** | **il ne clique pas — défaut n°1** |
| CTA | l'action est-elle nommée sans mot administratif ? | friction inutile |

**Le livrable est le plus souvent manquant.** Une ad qui explique parfaitement le problème et ne dit jamais ce qu'on donne au prospect produit de la reconnaissance — et la reconnaissance seule ne convertit pas (hook rate 35,9 %, zéro lead).

---

À passer un par un, en citant la ligne fautive. Ne jamais déclarer « conforme » sans avoir cité la ligne qui prouve la conformité.

---

## Filtre 1 — NOMMER, pas décrire

**Test :** le hook peut-il se préfixer par « tu es en train de te dire que… » sans grincer ?

- ✅ « Plus j'en fais, plus elle s'éloigne » → « tu es en train de te dire que plus t'en fais, plus elle s'éloigne » — tient
- ❌ « Après une rupture, on se sent perdu » → grince, c'est de l'observation

**Correction :** remplacer l'observation par la scène intérieure. Chercher dans les verbatims la phrase que personne ne dit à voix haute.

---

## Filtre 2 — Verbatim et chiffres sourcés

Pour chaque phrase attribuée au prospect et chaque chiffre : où est la source ?

- Verbatim → doit exister dans l'onboarding, un transcript ou un formulaire
- Chiffre → doit exister dans une donnée, marqué 🟢 ou 🟡
- Ancienneté, certification, rareté → doit être vérifiable

**Règle des chiffres ronds :** un chiffre rond sonne inventé. Préférer 227, 43 %, 31 € à « des centaines », « la moitié », « une trentaine d'euros ».

---

## Filtre 3 — Disculpation présente

L'ad absout-elle avant de demander ? Le prospect doit pouvoir reconnaître sans se détruire.

- ✅ « T'as été l'homme qu'elle voulait » avant « t'es resté trop longtemps »
- ✅ « C'est pas toi le problème, personne t'a appris »
- ❌ nommer le défaut sans validation préalable

**Sans disculpation, le prospect défend son noyau et ne clique pas.** C'est le mécanisme du hook Tally qui a cassé un compte.

---

## Filtre 4 — Mécanisme, pas verdict

L'ad explique-t-elle pourquoi ça échoue, ou l'affirme-t-elle ?

- ❌ « Tous ces conseils sont à côté »
- ✅ « On te dit quoi arrêter, jamais quoi faire — alors t'attends, et l'angoisse mouline »

**Test :** si le prospect demandait « pourquoi ? », l'ad a-t-elle déjà répondu ?

---

## Filtre 5 — Aucune promesse sur un tiers

Chercher toute affirmation sur ce que fera, pensera ou ressentira l'autre personne.

- ❌ « elle est encore attachée », « ton équipe va se remettre en marche », « ton ado va se rouvrir »
- ✅ « je te montre quoi lui envoyer », « un cadre où passer au travers devient impossible »

On promet un savoir, un geste, un cadre. Jamais une réaction.

---

## Filtre 6 — Zéro identité

L'ad nomme-t-elle un acte ou accuse-t-elle une nature ?

- ❌ « tu manques d'autorité », « tu n'es plus un homme », « t'es une mère toxique »
- ✅ « tu refais à leur place », « tu lui as écrit trois fois cette semaine »

**Toujours l'excès d'une qualité, jamais l'absence d'une qualité.**

**L'exception : la croyance rapportée.** Une formulation d'identité est légitime quand elle est citée comme ce que le prospect **se dit à lui-même**, et à condition que l'ad la contredise juste après.

- ✅ « Le soir, tu te dis que tu manques d'autorité. **C'est pas ça.** Personne t'a appris qu'une décision se pose. »
- ❌ « Tu manques d'autorité. »

C'est la même phrase. Dans le premier cas elle nomme sa croyance pour la déloger ; dans le second elle l'accuse. Le script signale les deux — c'est à l'audit humain de trancher, en vérifiant que la contradiction suit.

---

## Filtre 7 — Lexique et registre

Scanner mot à mot contre la liste interdite : *posture, masculinité, mindset, transformation, accompagnement, développement personnel, travailler sur toi, prise de conscience, lâcher-prise, bienveillance, alignement*.

Vérifier aussi :
- niveau de lecture 12 ans
- aucun mot qui réduit l'envergure de la cible
- « les hommes » jamais « les mecs »
- aucune précision temporelle fabriquée (heures exactes, jours nommés)

---

## Filtre 8 — Densité syllabique

**Cible : 218 à 246 syllabes pour 45 secondes.** Au-delà, la conversion se dégrade. 🟡

Le script `scripts/audit.py` compte automatiquement et signale les dépassements. Une ad trop dense se corrige en supprimant les phrases de liaison, pas en coupant les scènes.

---

# La procédure de décision : garder, couper, décliner

**Ne jamais décider sur le CTR seul.** Procédure en trois temps :

**1. Regarder le coût par lead qualifié.** Pas le CPL brut : le coût par lead qui passe le filtre. Une ad à 31 € le lead qualifié bat une ad à 8 € le lead non solvable.

**2. Croiser avec le comportement post-clic.** Durée de session médiane, taux de rebond sous 5 secondes, profondeur de lecture. C'est ce qui a démasqué une ad à 14,1 % de CTR dont la session médiane durait 1 seconde.

**3. Décider.**

| Situation | Décision |
|---|---|
| Bon coût qualifié + bon comportement | **décliner** — produire 3 variantes en gardant le mécanisme, en changeant la scène |
| Bon CTR + mauvais comportement | **couper** — le clic ne vaut rien |
| Mauvais CTR + bon comportement sur les rares qui passent | **garder à petit budget**, retravailler le hook seul |
| Rebond identique à celui des autres créas | **ne pas toucher à la créa** — le problème est en aval |
| Budget majoritaire sur le plus mauvais coût qualifié | **rééquilibrer immédiatement** — cas observé : 57 % du budget sur la pire créa qui délivre |

**Avant toute décision, vérifier le volume.** Une créa à 12 sessions ou 3 leads ne décide de rien. Marquer 🟡 et tester à budget égal sur sept jours.

---

# Comment décliner une winner

On ne décline jamais une winner en changeant ses mots. On garde le **mécanisme** et on change la **scène**.

Exemple sur « t'as été l'homme qu'elle voulait, t'es resté cet homme trop longtemps » :

- Mécanisme conservé : *excès d'une qualité + durée*
- Variante 1, autre excès : « Tu voulais bien faire. T'as tellement bien fait qu'elle n'a plus rien eu à venir chercher. »
- Variante 2, autre scène : « Tu répondais dans la minute. Elle a fini par ne plus se demander si tu répondrais. »
- Variante 3, autre entrée : « T'as tout donné. Le problème c'est pas ce que t'as donné — c'est qu'elle n'a jamais eu à le demander. »

Chaque variante repasse les 8 filtres. Une variante n'est pas dispensée d'audit.
