# ads-winners-loop

Skill de création d'ads Meta rentables — copy et offre uniquement.

## Installation (Claude Code)

Copier le dossier dans les skills du projet :

```bash
cp -r ads-winners-loop ~/.claude/skills/
# ou, pour un projet précis :
cp -r ads-winners-loop .claude/skills/
```

## Utilisation

Le skill se déclenche seul dès qu'il est question d'ad, de hook, d'angle, de perfs Meta ou d'offre. Sinon, l'appeler explicitement :

```
/ads-winners-loop écris-moi 3 ads sur l'angle "se justifier" pour Yohann
/ads-winners-loop audite cette ad
/ads-winners-loop voici mes perfs, qu'est-ce que je coupe ?
```

## Le contrôle machine

```bash
python3 scripts/audit.py mon_ad.txt --duree 45
cat mon_ad.txt | python3 audit.py - --duree 60
```

Code retour 1 s'il reste un bloquant. Aucune dépendance — Python 3 standard.

## Ce que contient le skill

| Fichier | Contenu |
|---|---|
| `SKILL.md` | principe, boucle, 6 blocs, états d'achat, lexique, filtres |
| `references/ads-reelles.md` | 12 ads réelles annotées, 3 comptes, performances chiffrées |
| `references/corrections.md` | 12 corrections avant/après, avec la raison |
| `references/audit.md` | les 9 filtres en détail + procédure garder/couper/décliner |
| `references/offre.md` | vendre les armes, prix, filtre financier, gates à éviter |
| `scripts/audit.py` | contrôle déterministe : lexique, densité, promesses, présence |

## Journal de la boucle de test

Le skill a été testé sur une ad neuve, avec quatre itérations et quatre corrections du skill lui-même :

1. **Faux positif** — « plus elle est discutable » détecté comme promesse sur l'ex. Regex restreinte aux vraies promesses d'état.
2. **Détection ratée** — « tu manques d'autorité » échappait au filtre à cause de l'apostrophe. Corrigé.
3. **Nuance manquante** — une formulation d'identité citée comme croyance du prospect n'est pas une accusation. Règle de la croyance rapportée ajoutée.
4. **Angle mort structurel** — les huit filtres étaient tous négatifs. Une ad pouvait ne rien violer et ne rien promettre. **Filtre 0 de présence créé**, avec contrôle machine des blocs manquants.

La quatrième est la plus importante : elle n'aurait jamais été trouvée sans écrire une ad de bout en bout.
