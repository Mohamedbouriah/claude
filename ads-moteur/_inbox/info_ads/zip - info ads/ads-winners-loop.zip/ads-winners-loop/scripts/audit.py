#!/usr/bin/env python3
"""
audit.py — controle deterministe d'une ad avant livraison.

Usage:
    python3 audit.py mon_ad.txt --duree 45
    cat mon_ad.txt | python3 audit.py - --duree 60

Attrape ce que la relecture rate : lexique interdit, densite syllabique,
chiffres ronds non sources, promesses sur un tiers, precision temporelle
fabriquee, marqueurs de langage genere.

Sortie : liste de violations avec la ligne fautive. Code retour 1 si violation.
Ce script ne remplace pas l'audit des 8 filtres : il le complete.
"""

import sys
import re
import argparse

# --- lexique interdit : mots de coach, tous comptes confondus -----------------
LEXIQUE = {
    "posture": "mot de coach — a fait derailler un compte entier",
    "masculinite": "accusation d'identite",
    "masculinité": "accusation d'identite",
    "mindset": "jargon",
    "transformation": "se livre, ne se vend pas",
    "accompagnement": "jargon — dire ce qu'on fait concretement",
    "developpement personnel": "jargon",
    "développement personnel": "jargon",
    "travailler sur toi": "accusation d'identite",
    "travail sur toi": "accusation d'identite",
    "bosser sur toi": "accusation d'identite",
    "prise de conscience": "jargon — nommer l'acte",
    "lacher-prise": "jargon",
    "lâcher-prise": "jargon",
    "bienveillance": "jargon",
    "alignement": "jargon",
    "aligne": "jargon",
    "haute valeur": "jargon",
    "reprendre le pouvoir": "jargon",
    "les mecs": "registre — dire 'les hommes'",
    "ton petit": "reduit l'envergure de la cible",
    "ton truc": "reduit l'envergure de la cible",
}

# --- promesses sur un tiers ---------------------------------------------------
TIERS = [
    (r"\belle (est|reste) (encore|toujours|deja|déjà)\b", "promesse sur l'etat de l'ex"),
    (r"\belle (t'aime|pense a toi|pense à toi|ressent|reviendra|va revenir)", "promesse sur l'ex"),
    (r"\belle (sera|voudra|acceptera|comprendra)\b", "promesse sur l'ex"),
    (r"\bton equipe va\b|\bton équipe va\b", "promesse sur l'equipe"),
    (r"\bton ado va\b|\bton enfant va\b", "promesse sur l'enfant"),
    (r"\bils vont (revenir|changer|comprendre|s'engager|ecouter|écouter)", "promesse sur des tiers"),
    (r"\bva (finir par |)(revenir|comprendre|changer)\b", "promesse de resultat sur un tiers"),
    (r"\bpour qu'ils?\s+\w+", "promesse sur ce que feront les autres"),
    (r"\bretrouvent? confiance en toi\b", "promesse sur ce que ressentiront les autres"),
]

# --- accusations d'identite ---------------------------------------------------
IDENTITE = [
    (r"\btu manques d[e']", "accuse une nature — nommer un acte"),
    (r"\btu n'?es pas (assez|un vrai)\b|\btu es pas (assez|un vrai)\b", "accuse une nature"),
    (r"\btu es (faible|toxique|nul|mauvais|trop gentil)", "accuse une nature"),
    (r"\bdeviens un (vrai|autre)\b", "vend l'identite"),
    (r"\bredeviens\b", "vend l'identite"),
    (r"\bmanque d'autorite\b|\bmanque d'autorité\b", "accuse une nature"),
]

# --- marqueurs de langage genere ---------------------------------------------
GENERE = [
    (r"\b\d{1,2}h\d{2}\b", "precision horaire fabriquee — parler par periodes"),
    (r"\b(lundi|mardi|mercredi|jeudi|vendredi|samedi|dimanche) \d{1,2}h", "scene minutee — sonne fabrique"),
    (r"\bil est important de\b|\bil convient de\b", "tournure administrative"),
    (r"\bn'hesitez pas\b|\bn'hésitez pas\b", "formule creuse"),
    (r"\bdans un monde ou\b|\bdans un monde où\b", "ouverture generique"),
    (r"\bque vous soyez\b", "adresse generique"),
    (r"—.*—.*—", "trop d'incises sur une ligne"),
]

# --- revendications a sourcer ---------------------------------------------------
CLAIMS = [
    (r"\bdepuis (plus de )?\d+ ans?\b", "anciennete — verifier la source, ne jamais l'inventer"),
    (r"\b\d+\s*% de (reussite|réussite|satisfaction)", "taux — verifier la source"),
    (r"\b(seulement |plus que |il ne reste )\d+ places?\b", "rarete — doit etre structurellement vraie"),
    (r"\bgaranti\b|\bgarantie de resultat\b", "garantie — verifier qu'elle existe vraiment"),
]

# --- croyance rapportee : downgrade des accusations citees ---------------------
RAPPORTE = re.compile(r"(tu te dis|tu penses que|il se dit|elle se dit|tu crois que|on te dit)", re.I)

# --- chiffres ronds suspects --------------------------------------------------
RONDS = re.compile(r"\b(\d*[05]0|100|1000|10000)\b(?!\s*%\s*(gratuit|rembours))")

# --- syllabes (approximation francaise) --------------------------------------
VOYELLES = "aeiouyàâäéèêëîïôöùûüÿ"
DIGRAPHES = ["ai", "au", "ay", "ea", "ei", "eu", "ey", "oi", "ou", "oy",
             "ui", "uy", "eau", "oeu", "ienne", "ion"]


def syllabes(mot):
    m = mot.lower()
    m = re.sub(r"[^a-zàâäéèêëîïôöùûüÿ]", "", m)
    if not m:
        return 0
    for d in sorted(DIGRAPHES, key=len, reverse=True):
        m = m.replace(d, "@")
    n = sum(1 for c in m if c in VOYELLES or c == "@")
    # e muet final
    if m.endswith("e") and n > 1:
        n -= 1
    return max(n, 1)


def compte_syllabes(texte):
    return sum(syllabes(w) for w in re.findall(r"[\w'àâäéèêëîïôöùûüÿ-]+", texte))


def audit(texte, duree):
    lignes = texte.split("\n")
    violations = []

    def add(niveau, regle, ligne_no, ligne, note):
        violations.append({
            "niveau": niveau, "regle": regle,
            "ligne_no": ligne_no, "ligne": ligne.strip()[:110], "note": note
        })

    for i, ligne in enumerate(lignes, 1):
        bas = ligne.lower()

        for mot, raison in LEXIQUE.items():
            if re.search(r"\b" + re.escape(mot), bas):
                add("BLOQUANT", f"lexique interdit « {mot} »", i, ligne, raison)

        for pat, raison in TIERS:
            if re.search(pat, bas):
                add("BLOQUANT", "promesse sur un tiers", i, ligne, raison)

        for pat, raison in IDENTITE:
            if re.search(pat, bas):
                # une croyance que le prospect se dit lui-meme n'est pas une accusation
                if RAPPORTE.search(ligne):
                    add("INFO", "croyance rapportee", i, ligne,
                        "formulation d'identite, mais citee comme ce que le prospect se dit — "
                        "legitime SI l'ad la contredit juste apres. Verifier.")
                else:
                    add("BLOQUANT", "accusation d'identite", i, ligne, raison)

        for pat, raison in CLAIMS:
            if re.search(pat, bas):
                add("AVERTISSEMENT", "revendication a sourcer", i, ligne, raison)

        for pat, raison in GENERE:
            if re.search(pat, bas):
                add("AVERTISSEMENT", "marqueur de langage genere", i, ligne, raison)

        for m in RONDS.finditer(ligne):
            add("AVERTISSEMENT", f"chiffre rond « {m.group(0)} »",
                i, ligne, "un chiffre rond sonne invente — sourcer ou preciser")

    # --- controle de PRESENCE : les filtres negatifs ne suffisent pas.
    # Une ad peut ne rien violer et ne rien promettre.
    bas_all = texte.lower()
    presence = [
        (r"\bc'est pas (toi|ca|ça)\b|personne (t'a|ne t'a) (jamais )?appris|\bnormal\b|c'est le cas de",
         "DISCULPATION absente — le prospect va defendre son noyau"),
        (r"\bplus tu\b.{0,60}\bplus\b|\bparce que\b|\bdonc\b|\bc'est pour ca\b|c'est pour ça",
         "MECANISME absent — l'ad affirme sans expliquer"),
        (r"\b\d+\b", "CHIFFRE VERIFIABLE absent — aucune incarnation chiffree"),
        (r"je (te|vous) (montre|dis|donne|envoie)|tu (repars|obtiens|recois|reçois)|tu vas savoir|voila ce que|voilà ce que",
         "LIVRABLE absent — le prospect ne sait pas ce qu'il obtient"),
    ]
    for pat, manque in presence:
        if not re.search(pat, bas_all):
            violations.append({"niveau": "BLOQUANT", "regle": "bloc manquant",
                               "ligne_no": 0, "ligne": "", "note": manque})

    # densite
    syl = compte_syllabes(texte)
    cible_bas = int(218 * duree / 45)
    cible_haut = int(246 * duree / 45)
    densite = {"syllabes": syl, "cible": (cible_bas, cible_haut), "duree": duree}
    if syl > cible_haut:
        violations.append({
            "niveau": "BLOQUANT", "regle": "densite syllabique",
            "ligne_no": 0, "ligne": "",
            "note": f"{syl} syllabes pour {duree}s — cible {cible_bas}-{cible_haut}. "
                    f"Couper {syl - cible_haut} syllabes : supprimer les liaisons, garder les scenes."
        })
    elif syl < cible_bas:
        violations.append({
            "niveau": "INFO", "regle": "densite syllabique",
            "ligne_no": 0, "ligne": "",
            "note": f"{syl} syllabes pour {duree}s — cible {cible_bas}-{cible_haut}. Marge disponible."
        })

    return violations, densite


def main():
    p = argparse.ArgumentParser()
    p.add_argument("fichier", help="fichier de l'ad, ou - pour stdin")
    p.add_argument("--duree", type=int, default=45, help="duree cible en secondes")
    a = p.parse_args()

    texte = sys.stdin.read() if a.fichier == "-" else open(a.fichier, encoding="utf-8").read()
    violations, densite = audit(texte, a.duree)

    bloquants = [v for v in violations if v["niveau"] == "BLOQUANT"]
    avert = [v for v in violations if v["niveau"] == "AVERTISSEMENT"]
    infos = [v for v in violations if v["niveau"] == "INFO"]

    print(f"\nDensite : {densite['syllabes']} syllabes pour {densite['duree']}s "
          f"(cible {densite['cible'][0]}-{densite['cible'][1]})")
    print(f"Bloquants : {len(bloquants)} | Avertissements : {len(avert)}\n")

    for groupe, titre in ((bloquants, "BLOQUANTS"), (avert, "AVERTISSEMENTS"), (infos, "INFOS")):
        if not groupe:
            continue
        print(f"--- {titre} ---")
        for v in groupe:
            loc = f"L{v['ligne_no']}" if v["ligne_no"] else "global"
            print(f"  [{loc}] {v['regle']}")
            if v["ligne"]:
                print(f"        > {v['ligne']}")
            print(f"        {v['note']}")
        print()

    if bloquants:
        print("RESULTAT : ad NON livrable. Reecrire et relancer l'audit.\n")
        sys.exit(1)
    print("RESULTAT : controle machine passe. "
          "Passer maintenant les 8 filtres a la main (references/audit.md).\n")
    sys.exit(0)


if __name__ == "__main__":
    main()
