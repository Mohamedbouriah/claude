#!/usr/bin/env bash
# 06-create-agent.sh — Crée un agent perso avec soul.md à partir des réponses utilisateur

set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/lib/colors.sh"
source "$SCRIPT_DIR/lib/log.sh"
source "$SCRIPT_DIR/lib/ask.sh"

[ -f /tmp/claude-setup-env.sh ] && source /tmp/claude-setup-env.sh
BRAIN_PATH="${CS_BRAIN_PATH:-$HOME/brainOS}"
USER_NAME="${CS_USER_NAME:-Dev}"

log_step "06" "Création d'un agent perso"

if ! ask_yes_no "Tu veux créer un agent perso (avec soul.md) ?" "y"; then
  log_skip "Agent perso skippé"
  exit 0
fi

AGENT_ID="$(ask "Nom (id) de l'agent" "bro")"
# Sanitize
AGENT_ID="$(printf '%s' "$AGENT_ID" | tr '[:upper:]' '[:lower:]' | tr -cd 'a-z0-9_-')"
[ -z "$AGENT_ID" ] && AGENT_ID="bro"

AGENT_TONE="$(ask_choice "Ton de l'agent" "formel|direct|cool" "direct")"

AGENT_DIR="$BRAIN_PATH/agents/$AGENT_ID"
if [ -d "$AGENT_DIR" ] && [ -f "$AGENT_DIR/soul.md" ]; then
  log_skip "Agent $AGENT_ID existe déjà — préservé"
  exit 0
fi

mkdir -p "$AGENT_DIR"

TEMPLATES_DIR="$SCRIPT_DIR/../templates"

# Construis un descripteur de ton
case "$AGENT_TONE" in
  formel)
    TONE_DESC="Tu t'exprimes de manière professionnelle et structurée. Tu vouvoies par défaut."
    ;;
  direct)
    TONE_DESC="Tu vas droit au but. Phrases courtes. Zéro filler. Tu tutoies."
    ;;
  cool)
    TONE_DESC="Tu es détendu, complice, parfois drôle. Tu tutoies. Vocabulaire familier OK."
    ;;
  *)
    TONE_DESC="Tu vas droit au but. Phrases courtes. Zéro filler."
    ;;
esac

sed -e "s|{{AGENT_ID}}|$AGENT_ID|g" \
    -e "s|{{USER_NAME}}|$USER_NAME|g" \
    -e "s|{{TONE}}|$AGENT_TONE|g" \
    -e "s|{{TONE_DESC}}|$TONE_DESC|g" \
    "$TEMPLATES_DIR/soul.md" > "$AGENT_DIR/soul.md"

log_ok "Agent $AGENT_ID créé : $AGENT_DIR/soul.md"

# Bonus : copie le CLAUDE.md template à la racine du Second Brain (sert de doc Claude Code projet-wide)
if [ ! -f "$BRAIN_PATH/CLAUDE.md" ]; then
  sed -e "s|{{AGENT_ID}}|$AGENT_ID|g" \
      -e "s|{{USER_NAME}}|$USER_NAME|g" \
      -e "s|{{BRAIN_PATH}}|$BRAIN_PATH|g" \
      "$TEMPLATES_DIR/CLAUDE.md" > "$BRAIN_PATH/CLAUDE.md"
  log_ok "CLAUDE.md créé à la racine du Second Brain"
fi

echo "export CS_AGENT_ID=\"$AGENT_ID\"" >> /tmp/claude-setup-env.sh
log_done "Agent perso prêt"
