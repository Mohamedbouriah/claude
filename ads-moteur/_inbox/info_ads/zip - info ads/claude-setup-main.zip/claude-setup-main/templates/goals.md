# Goals

Track active objectives here. Reformulate any new goal as actionable to-dos.

## North Star

_What's the single outcome you're optimizing for in the next 6 months?_

- [ ] Define your North Star

## This week

- [ ] (empty)

## Today

- [ ] (empty)

## Backlog

- [ ] (empty)

---

## Done — Archive

_Move completed items here with a date stamp._
