#!/usr/bin/env bash
# colors.sh — ANSI color codes for terminal output
# Source this file: source "$SCRIPT_DIR/lib/colors.sh"

# Detect TTY — disable colors if redirected to file
if [ -t 1 ]; then
  export C_RESET='\033[0m'
  export C_BOLD='\033[1m'
  export C_DIM='\033[2m'

  export C_RED='\033[0;31m'
  export C_GREEN='\033[0;32m'
  export C_YELLOW='\033[0;33m'
  export C_BLUE='\033[0;34m'
  export C_MAGENTA='\033[0;35m'
  export C_CYAN='\033[0;36m'
  export C_WHITE='\033[0;37m'

  export C_BRED='\033[1;31m'
  export C_BGREEN='\033[1;32m'
  export C_BYELLOW='\033[1;33m'
  export C_BBLUE='\033[1;34m'
  export C_BMAGENTA='\033[1;35m'
  export C_BCYAN='\033[1;36m'
else
  export C_RESET=''
  export C_BOLD=''
  export C_DIM=''
  export C_RED=''
  export C_GREEN=''
  export C_YELLOW=''
  export C_BLUE=''
  export C_MAGENTA=''
  export C_CYAN=''
  export C_WHITE=''
  export C_BRED=''
  export C_BGREEN=''
  export C_BYELLOW=''
  export C_BBLUE=''
  export C_BMAGENTA=''
  export C_BCYAN=''
fi
