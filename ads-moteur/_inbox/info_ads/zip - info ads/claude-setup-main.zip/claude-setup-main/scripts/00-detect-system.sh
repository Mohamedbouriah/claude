#!/usr/bin/env bash
# 00-detect-system.sh — Detects OS, shell, runtimes, package managers
# Outputs a sourcable env file at /tmp/claude-setup-env.sh

set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/lib/colors.sh"
source "$SCRIPT_DIR/lib/log.sh"

log_step "00" "Détection du système"

DETECT_FILE="/tmp/claude-setup-env.sh"
: > "$DETECT_FILE"

# OS
OS="$(uname -s)"
ARCH="$(uname -m)"
log_info "OS:    $OS ($ARCH)"
echo "export CS_OS=\"$OS\"" >> "$DETECT_FILE"
echo "export CS_ARCH=\"$ARCH\"" >> "$DETECT_FILE"

# Shell
USER_SHELL="${SHELL:-/bin/bash}"
log_info "Shell: $USER_SHELL"
echo "export CS_SHELL=\"$USER_SHELL\"" >> "$DETECT_FILE"

# Runtimes
check_cmd() {
  local cmd="$1"
  local var="$2"
  if command -v "$cmd" >/dev/null 2>&1; then
    local path
    path="$(command -v "$cmd")"
    log_ok "$cmd → $path"
    echo "export ${var}=\"$path\"" >> "$DETECT_FILE"
    echo "export ${var}_INSTALLED=1" >> "$DETECT_FILE"
  else
    log_skip "$cmd (non installé)"
    echo "export ${var}_INSTALLED=0" >> "$DETECT_FILE"
  fi
}

check_cmd node     CS_NODE
check_cmd bun      CS_BUN
check_cmd python3  CS_PYTHON
check_cmd npm      CS_NPM
check_cmd pnpm     CS_PNPM
check_cmd yarn     CS_YARN
check_cmd brew     CS_BREW
check_cmd gh       CS_GH
check_cmd vercel   CS_VERCEL
check_cmd claude   CS_CLAUDE
check_cmd jq       CS_JQ
check_cmd git      CS_GIT
check_cmd curl     CS_CURL

log_done "Détection terminée — env exporté dans $DETECT_FILE"
