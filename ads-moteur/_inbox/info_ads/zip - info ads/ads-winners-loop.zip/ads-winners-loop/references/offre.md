# L'offre — ce qui se vend, ce qui se livre, à quel prix

---

## La loi centrale

> **On vend les armes. On livre la transformation.**

L'ad promet un savoir et des gestes. L'accompagnement produit un changement d'identité. Les deux sont vrais — mais **on ne vend jamais le second**.

**Preuve :** le seul appel closé du corpus est resté sur le livrable — « je vais te montrer quoi lui envoyer, je suis derrière toi sur chaque message ». Quatre appels perdus sur sept ont basculé sur l'identité. 🟢

**Preuve inverse :** dans les questionnaires remplis **en cours d'accompagnement**, les clients emploient spontanément le vocabulaire de la transformation — « meilleure version de moi-même », « renaître comme un phénix ». Ils ne l'ont pas acheté. Ils l'ont trouvé dedans.

---

## Les trois barreaux

Un prospect ne monte jamais deux barreaux d'un coup.

| Niveau | Ce qu'il demande | Taux de close |
|---|---|---|
| **N2 — la technique** | « donne-moi la méthode » | 0,7 % |
| **N3 — les armes, avec l'aveu fait** | « je sais ce que j'ai à changer, montre-moi comment » | **10,5 %** 🟢 |
| **Niveau identité** | jamais demandé, jamais exigé | — |

**Écart mesuré : ×15.** Toute l'architecture de l'offre sert à faire passer du premier au deuxième barreau — jamais au troisième.

---

## L'aveu tolérable

La formulation qui rend l'aveu possible sans détruire le prospect :

> **« T'as pas mal fait. T'as trop fait. »**

Toujours **l'excès d'une qualité**, jamais l'absence d'une qualité.

| Niche | Excès formulé | À ne jamais dire |
|---|---|---|
| Reconquête | « trop disponible », « ta peur de la perdre a pris le contrôle » | « tu manques de virilité » |
| Parentalité | « trop de contrôle, parce que trop de peur » | « tu es une mauvaise mère » |
| Management | « tu refais à leur place parce que c'est plus rapide » | « tu manques d'autorité » |

---

## La promesse

Trois critères, cumulatifs :

**Concrète** — un livrable qu'on peut se représenter. « Les messages exacts à lui envoyer », « deux jours hors du bureau », pas « retrouver confiance ».

**Sans promesse sur un tiers** — « ton équipe arrête de dépendre de toi » est acceptable (c'est un cadre) ; « ton équipe va s'engager » ne l'est pas (c'est leur décision).

**Chiffrée quand c'est possible** — en B2B, le coût de l'inaction rend la dépense légitime face à un associé. Un dirigeant qui perd 8 heures par semaine perd 391 heures par an, soit 11 semaines de travail. Face à ça, deux jours cessent d'être une dépense pour devenir un calcul.

---

## Le prix et le filtre financier

**Le mindset prédit, pas le revenu.** 🟢

| Réponse à « niveau argent, t'en es où ? » | Taux de close |
|---|---|
| « Si c'est ce qu'il me faut, je trouve les moyens » | **33 %** |
| « C'est tendu, mais je suis prêt » | 11 % |
| « Si ça matche » / « je cherchais des pistes » | **0 %** |

**Conséquences pour le copy :**
- Le prix se pose pour le **décidé-tendu**, pas pour le riche
- La question financière se pré-cadre par le livrable : « je donne pas des astuces en vrac — je te montre quoi faire et quoi lui envoyer, étape par étape. Et je prends que les hommes vraiment engagés. »
- **Poser la question sans appliquer le routage ne sert à rien.** Sur un compte, la disqualification est passée de 67 % à 1,3 % : ils viennent, et ils n'achètent pas.

---

## Les gates à ne jamais mettre

Trois filtres d'entrée excluaient les vrais acheteurs :

- **Historique de coaching** — 88 % des payants n'avaient jamais payé de coaching. Le gate éliminait la quasi-totalité du marché. 🟢
- **Statut professionnel déclaré** — élimine des acheteurs solvables et n'attrape aucun insolvable
- **Revenu déclaré** — le mindset prédit, pas le revenu

**Ce qui filtre vraiment :** l'aveu sur un acte, l'échéance réelle, le rapport à l'argent formulé comme une décision.

---

## L'urgence — réelle, jamais fabriquée

70 % des acheteurs signent en moins de 7 jours, 44 % en moins de 48 heures. 🟢

L'urgence n'a donc **pas besoin d'être inventée** : elle est dans le comportement. Le copy peut la nommer (« chaque semaine qui passe, elle s'habitue un peu plus à une vie sans toi ») sans jamais fabriquer de fausse rareté.

La rareté, si elle est employée, doit être **structurellement vraie** : une capacité d'accompagnement réelle, un nombre de places réel. Un plafond observé de 3 à 6 clients par mois rend « sept par semaine, pas plus » défendable — pas décoratif.

---

## L'upsell

Le déclencheur est observable dans le discours : **le jour où le client parle plus de lui que du problème initial.**

Matière mesurée sur une base de clients en cours : le mot qui traverse toutes les réponses est **confiance**. Les trois piliers d'une offre 2 sont la confiance, le rapport aux autres, et la vie à soi.

**Et ici seulement, le vocabulaire de la transformation est permis** — parce que c'est le client qui l'emploie en premier. On vend les armes à l'entrée ; la transformation se vend toute seule à l'intérieur.
