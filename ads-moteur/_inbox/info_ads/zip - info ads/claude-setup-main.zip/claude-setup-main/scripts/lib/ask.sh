#!/usr/bin/env bash
# ask.sh — user prompt helpers with validation
# Source after colors.sh and log.sh

# ask "Question" "default_value" → echoes the answer
ask() {
  local question="$1"
  local default="${2:-}"
  local answer=""

  if [ -n "$default" ]; then
    printf "${C_BCYAN}?${C_RESET} %s ${C_DIM}[%s]${C_RESET}: " "$question" "$default" >&2
  else
    printf "${C_BCYAN}?${C_RESET} %s: " "$question" >&2
  fi

  read -r answer
  if [ -z "$answer" ] && [ -n "$default" ]; then
    answer="$default"
  fi
  printf "%s" "$answer"
}

# ask_yes_no "Question" "y" → 0 if yes, 1 if no
ask_yes_no() {
  local question="$1"
  local default="${2:-y}"
  local prompt
  if [ "$default" = "y" ]; then
    prompt="Y/n"
  else
    prompt="y/N"
  fi

  local answer=""
  printf "${C_BCYAN}?${C_RESET} %s ${C_DIM}[%s]${C_RESET}: " "$question" "$prompt" >&2
  read -r answer
  answer="${answer:-$default}"

  case "$answer" in
    [Yy]|[Yy][Ee][Ss]) return 0 ;;
    *) return 1 ;;
  esac
}

# ask_choice "Question" "opt1|opt2|opt3" "opt1"
ask_choice() {
  local question="$1"
  local options="$2"
  local default="$3"

  printf "${C_BCYAN}?${C_RESET} %s ${C_DIM}(%s)${C_RESET} ${C_DIM}[%s]${C_RESET}: " "$question" "$options" "$default" >&2
  local answer=""
  read -r answer
  answer="${answer:-$default}"
  printf "%s" "$answer"
}

# ask_secret "Question" → reads silently, echoes result (only used for env file write)
ask_secret() {
  local question="$1"
  local answer=""
  printf "${C_BCYAN}?${C_RESET} %s ${C_DIM}(masqué)${C_RESET}: " "$question" >&2
  stty -echo
  read -r answer
  stty echo
  printf "\n" >&2
  printf "%s" "$answer"
}
